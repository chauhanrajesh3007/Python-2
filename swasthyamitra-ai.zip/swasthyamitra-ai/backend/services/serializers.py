"""
Services — DRF Serializers
"""
from rest_framework import serializers
from .models import Appointment, MedicineReminder, AmbulanceRequest, Subscription


class AppointmentSerializer(serializers.ModelSerializer):
    patient_name = serializers.CharField(source='patient.full_name', read_only=True)
    doctor_name = serializers.CharField(source='doctor.full_name', read_only=True)

    class Meta:
        model = Appointment
        fields = '__all__'
        read_only_fields = [
            'patient', 'status', 'razorpay_order_id', 'razorpay_payment_id',
            'video_call_url', 'patient_name', 'doctor_name', 'created_at', 'updated_at',
        ]

    def validate(self, data):
        # Prevent double-booking same doctor slot
        doctor = data.get('doctor')
        appointment_date = data.get('appointment_date')
        slot_start = data.get('slot_start_time')
        if Appointment.objects.filter(
            doctor=doctor,
            appointment_date=appointment_date,
            slot_start_time=slot_start,
        ).exclude(status=Appointment.Status.CANCELLED).exists():
            raise serializers.ValidationError(
                'This slot is already booked. Please choose another time.'
            )
        return data


class MedicineReminderSerializer(serializers.ModelSerializer):
    class Meta:
        model = MedicineReminder
        fields = '__all__'
        read_only_fields = ['patient', 'last_sent_at', 'created_at']


class AmbulanceRequestSerializer(serializers.ModelSerializer):
    patient_name = serializers.CharField(source='patient.full_name', read_only=True)
    driver_name = serializers.CharField(source='driver.full_name', read_only=True)
    driver_phone = serializers.CharField(source='driver.phone', read_only=True)

    class Meta:
        model = AmbulanceRequest
        fields = '__all__'
        read_only_fields = [
            'patient', 'driver', 'status', 'driver_eta_minutes',
            'patient_name', 'driver_name', 'driver_phone',
            'created_at', 'updated_at',
        ]


class SubscriptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Subscription
        fields = '__all__'
        read_only_fields = [
            'patient', 'tier', 'razorpay_subscription_id', 'created_at', 'updated_at',
        ]
