import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Loader2, Phone, MapPin, Clock, AlertTriangle, Ambulance } from 'lucide-react';
import api from '../services/api';

export default function EmergencyPage() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [locating, setLocating] = useState(false);

  const findAmbulance = async (lat, lon) => {
    setLoading(true);
    setError('');
    try {
      const res = await api.post('/services/nearest-ambulance/', {
        latitude: lat, longitude: lon,
      });
      setResult(res.data);
    } catch (err) {
      setError('Failed to find ambulance. Call 108 for emergency.');
    } finally {
      setLoading(false);
      setLocating(false);
    }
  };

  const handleSOS = () => {
    setLocating(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          findAmbulance(pos.coords.latitude, pos.coords.longitude);
        },
        () => {
          // Fallback: use Ahmedabad coordinates
          findAmbulance(23.0225, 72.5714);
        },
        { timeout: 10000 }
      );
    } else {
      findAmbulance(23.0225, 72.5714);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 py-4">
        <div className="max-w-2xl mx-auto flex items-center gap-4">
          <Link to="/patient-dashboard" className="text-gray-500 hover:text-gray-700">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-lg font-semibold text-red-600">Emergency SOS</h1>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-8">
        {/* SOS Button */}
        {!result && (
          <div className="text-center">
            <button
              onClick={handleSOS}
              disabled={loading || locating}
              className="w-48 h-48 bg-red-600 hover:bg-red-700 text-white rounded-full
                         flex flex-col items-center justify-center shadow-2xl
                         transition-all duration-300 active:scale-95
                         disabled:opacity-70 mx-auto animate-pulse"
            >
              {loading || locating ? (
                <Loader2 className="w-12 h-12 animate-spin" />
              ) : (
                <>
                  <AlertTriangle className="w-12 h-12 mb-2" />
                  <span className="text-2xl font-black">SOS</span>
                </>
              )}
            </button>
            <p className="text-gray-600 mt-6 text-lg">
              {locating ? 'Getting your location...' : 'Tap for emergency ambulance dispatch'}
            </p>
            <p className="text-gray-400 text-sm mt-2">
              Or dial <span className="font-bold text-red-600">108</span> for national ambulance helpline
            </p>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-center">
            {error}
          </div>
        )}

        {/* Ambulance Found */}
        {result?.found && result.driver && (
          <div className="card space-y-5">
            <div className="flex items-center gap-3 text-green-700 bg-green-50 px-4 py-3 rounded-lg">
              <Ambulance className="w-6 h-6" />
              <span className="font-semibold">Ambulance Found!</span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-600 font-medium">Driver</p>
                <p className="text-lg font-bold">{result.driver.name}</p>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-600 font-medium">Vehicle</p>
                <p className="text-lg font-bold">{result.driver.vehicle_number}</p>
              </div>
              <div className="p-4 bg-yellow-50 rounded-lg flex items-center gap-2">
                <MapPin className="w-4 h-4 text-yellow-600" />
                <div>
                  <p className="text-sm text-yellow-600 font-medium">Distance</p>
                  <p className="text-lg font-bold">{result.distance_km} km</p>
                </div>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg flex items-center gap-2">
                <Clock className="w-4 h-4 text-purple-600" />
                <div>
                  <p className="text-sm text-purple-600 font-medium">ETA</p>
                  <p className="text-lg font-bold">{result.eta_minutes} min</p>
                </div>
              </div>
            </div>

            {result.driver.phone && (
              <a
                href={`tel:${result.driver.phone}`}
                className="btn-primary w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700"
              >
                <Phone className="w-5 h-5" />
                Call Driver — {result.driver.phone}
              </a>
            )}
          </div>
        )}

        {/* No Ambulance */}
        {result && !result.found && (
          <div className="card text-center">
            <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-gray-900">No Ambulance Available</h2>
            <p className="text-gray-600 mt-2">{result.message}</p>
            <a href="tel:108" className="btn-primary mt-6 inline-flex items-center gap-2">
              <Phone className="w-4 h-4" /> Call 108 Helpline
            </a>
          </div>
        )}
      </main>
    </div>
  );
}
