import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Calendar, Clock, Video, Loader2, User, IndianRupee } from 'lucide-react';
import api from '../services/api';

const STATUS_COLORS = {
  PENDING: 'bg-yellow-100 text-yellow-800',
  PAID: 'bg-green-100 text-green-800',
  IN_PROGRESS: 'bg-blue-100 text-blue-800',
  COMPLETED: 'bg-gray-100 text-gray-600',
  CANCELLED: 'bg-red-100 text-red-800',
};

export default function AppointmentsPage() {
  const [appointments, setAppointments] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [booking, setBooking] = useState(false);
  const [form, setForm] = useState({ doctor: '', appointment_date: '', slot_start_time: '10:00', symptoms_summary: '' });

  const loadAppointments = async () => {
    try {
      const res = await api.get('/services/appointments/');
      setAppointments(res.data.results || res.data);
    } catch (err) { /* silent */ }
  };

  const loadDoctors = async () => {
    try {
      const res = await api.get('/auth/doctors/');
      setDoctors(res.data.results || res.data);
    } catch (err) { /* silent */ }
  };

  useEffect(() => {
    Promise.all([loadAppointments(), loadDoctors()]).finally(() => setLoading(false));
  }, []);

  const handleBook = async (e) => {
    e.preventDefault();
    setBooking(true);
    try {
      await api.post('/services/appointments/', {
        doctor: parseInt(form.doctor),
        appointment_date: form.appointment_date,
        slot_start_time: form.slot_start_time + ':00',
        slot_end_time: form.slot_start_time.split(':')[0] + ':30:00',
        symptoms_summary: form.symptoms_summary,
      });
      await loadAppointments();
      setForm({ doctor: '', appointment_date: '', slot_start_time: '10:00', symptoms_summary: '' });
    } catch (err) {
      alert(err.response?.data?.detail || err.response?.data?.error || 'Booking failed');
    } finally {
      setBooking(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 py-4">
        <div className="max-w-4xl mx-auto flex items-center gap-4">
          <Link to="/patient-dashboard" className="text-gray-500 hover:text-gray-700">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-lg font-semibold">Appointments</h1>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        {/* Book New */}
        <div className="card">
          <h2 className="font-semibold text-lg mb-4">Book an Appointment</h2>
          <form onSubmit={handleBook} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Select Doctor</label>
                <select className="input-field" value={form.doctor} onChange={(e) => setForm({ ...form, doctor: e.target.value })} required>
                  <option value="">— Choose Doctor —</option>
                  {doctors.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.user.first_name} {d.user.last_name} — {d.specialization} (₹{d.consultation_fee})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Date</label>
                <input type="date" className="input-field" value={form.appointment_date} onChange={(e) => setForm({ ...form, appointment_date: e.target.value })} required min={new Date().toISOString().split('T')[0]} />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Time</label>
                <input type="time" className="input-field" value={form.slot_start_time} onChange={(e) => setForm({ ...form, slot_start_time: e.target.value })} required />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Symptoms (optional)</label>
                <input type="text" className="input-field" placeholder="Brief summary..." value={form.symptoms_summary} onChange={(e) => setForm({ ...form, symptoms_summary: e.target.value })} />
              </div>
            </div>
            <button type="submit" disabled={booking} className="btn-primary w-full flex items-center justify-center gap-2">
              {booking && <Loader2 className="w-4 h-4 animate-spin" />}
              {booking ? 'Booking...' : 'Book Appointment'}
            </button>
          </form>
        </div>

        {/* My Appointments */}
        <div className="card">
          <h2 className="font-semibold text-lg mb-4">My Appointments</h2>
          {appointments.length === 0 ? (
            <p className="text-gray-500 text-sm text-center py-8">No appointments yet.</p>
          ) : (
            <div className="space-y-3">
              {appointments.map((a) => (
                <div key={a.id} className="p-4 bg-gray-50 rounded-lg border border-gray-200 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-gray-500" />
                      <span className="font-medium">Dr. {a.doctor_name || `Doctor #${a.doctor}`}</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm text-gray-500 mt-1">
                      <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {a.appointment_date}</span>
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {a.slot_start_time}</span>
                      <span className="flex items-center gap-1"><IndianRupee className="w-3 h-3" /> {a.consultation_fee}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${STATUS_COLORS[a.status] || 'bg-gray-100'}`}>
                      {a.status}
                    </span>
                    {a.video_call_url && (
                      <a href={a.video_call_url} target="_blank" rel="noopener noreferrer"
                         className="flex items-center gap-1 text-blue-600 hover:text-blue-800 text-sm font-medium">
                        <Video className="w-4 h-4" /> Join
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
