"""
Accounts — DRF Serializers
"""
from django.contrib.auth import authenticate, get_user_model
from django.core.exceptions import ValidationError
from rest_framework import serializers
from .models import (
    User, PatientProfile, DoctorProfile, AmbulanceDriverProfile,
    DoctorAvailabilitySlot,
)

User = get_user_model()


# ═══════════════════════════════════════════════════════════════════════════
# User Registration
# ═══════════════════════════════════════════════════════════════════════════

class UserRegisterSerializer(serializers.ModelSerializer):
    """Handles registration for all roles with role-specific profiles."""

    password = serializers.CharField(write_only=True, min_length=8, max_length=128)
    confirm_password = serializers.CharField(write_only=True)

    # ── Patient-specific fields ──
    age = serializers.IntegerField(
        required=False, min_value=1,
        help_text='Required for PATIENT role'
    )
    gender = serializers.ChoiceField(
        choices=PatientProfile.Gender.choices, required=False,
        help_text='MALE or FEMALE'
    )
    blood_group = serializers.ChoiceField(
        choices=PatientProfile.BLOOD_GROUP_CHOICES, required=False
    )
    medical_history = serializers.CharField(required=False, allow_blank=True)

    # ── Doctor-specific fields ──
    specialization = serializers.CharField(required=False, allow_blank=True)
    clinic_hospital_name = serializers.CharField(required=False, allow_blank=True)
    registration_number = serializers.CharField(required=False, allow_blank=True)
    consultation_fee = serializers.DecimalField(
        required=False, max_digits=8, decimal_places=2,
    )

    # ── Driver-specific fields ──
    vehicle_number = serializers.CharField(required=False, allow_blank=True)
    vehicle_type = serializers.CharField(required=False, allow_blank=True)

    class Meta:
        model = User
        fields = [
            'email', 'password', 'confirm_password',
            'first_name', 'last_name', 'phone', 'role',
            # Patient
            'age', 'gender', 'blood_group', 'medical_history',
            # Doctor
            'specialization', 'clinic_hospital_name', 'registration_number',
            'consultation_fee',
            # Driver
            'vehicle_number', 'vehicle_type',
        ]

    def validate_email(self, value):
        return value.strip().lower()

    def validate(self, data):
        """Cross-field validation."""
        if data.get('password') != data.pop('confirm_password', None):
            raise serializers.ValidationError({'confirm_password': 'Passwords do not match.'})

        role = data.get('role', User.Role.PATIENT)

        if role == User.Role.PATIENT:
            if not data.get('age'):
                raise serializers.ValidationError({'age': 'Age is required for patients.'})
            if not data.get('gender'):
                raise serializers.ValidationError({'gender': 'Gender is required for patients.'})

        elif role == User.Role.DOCTOR:
            if not data.get('specialization'):
                raise serializers.ValidationError({'specialization': 'Specialization is required.'})
            if not data.get('registration_number'):
                raise serializers.ValidationError({'registration_number': 'Registration number is required.'})

        elif role == User.Role.AMBULANCE_DRIVER:
            if not data.get('vehicle_number'):
                raise serializers.ValidationError({'vehicle_number': 'Vehicle number is required.'})

        return data

    def create(self, validated_data):
        role = validated_data.get('role', User.Role.PATIENT)
        profile_fields = {}

        for field in ('age', 'gender', 'blood_group', 'medical_history',
                      'specialization', 'clinic_hospital_name', 'registration_number',
                      'consultation_fee', 'vehicle_number', 'vehicle_type'):
            profile_fields[field] = validated_data.pop(field, None)

        password = validated_data.pop('password')
        user = User(**validated_data)
        user.set_password(password)
        user.save()

        # Create the role-specific profile
        if role == User.Role.PATIENT:
            PatientProfile.objects.create(
                user=user,
                age=profile_fields['age'],
                gender=(profile_fields['gender'] or '').upper(),
                blood_group=profile_fields.get('blood_group') or '',
                medical_history=profile_fields.get('medical_history') or '',
            )
        elif role == User.Role.DOCTOR:
            DoctorProfile.objects.create(
                user=user,
                specialization=profile_fields['specialization'],
                clinic_hospital_name=profile_fields.get('clinic_hospital_name') or '',
                registration_number=profile_fields['registration_number'],
                consultation_fee=profile_fields.get('consultation_fee') or 199.00,
            )
        elif role == User.Role.AMBULANCE_DRIVER:
            AmbulanceDriverProfile.objects.create(
                user=user,
                vehicle_number=profile_fields['vehicle_number'],
                vehicle_type=profile_fields.get('vehicle_type') or 'Basic Life Support',
            )

        return user


# ═══════════════════════════════════════════════════════════════════════════
# Login
# ═══════════════════════════════════════════════════════════════════════════

class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField()

    def validate(self, data):
        email = data['email'].strip().lower()
        password = data['password']
        user = authenticate(request=self.context.get('request'), email=email, password=password)
        if not user:
            raise serializers.ValidationError('Invalid email or password.')
        if not user.is_active:
            raise serializers.ValidationError('This account has been deactivated.')
        data['user'] = user
        return data


# ═══════════════════════════════════════════════════════════════════════════
# Profiles (read / update)
# ═══════════════════════════════════════════════════════════════════════════

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'email', 'role', 'first_name', 'last_name', 'phone', 'is_verified']
        read_only_fields = ['id', 'email', 'role', 'is_verified']


class PatientProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = PatientProfile
        fields = '__all__'
        read_only_fields = ['user', 'daily_ai_check_count', 'last_ai_check_date']

    def validate_gender(self, value):
        return value.upper() if value else value


class DoctorProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    availability_slots = serializers.SerializerMethodField()

    class Meta:
        model = DoctorProfile
        fields = '__all__'
        read_only_fields = ['user', 'rating']

    def get_availability_slots(self, obj):
        return DoctorAvailabilitySlotSerializer(
            obj.availability_slots.all(), many=True
        ).data


class DoctorAvailabilitySlotSerializer(serializers.ModelSerializer):
    class Meta:
        model = DoctorAvailabilitySlot
        fields = ['id', 'day_of_week', 'start_time', 'end_time', 'max_patients_per_slot']


class AmbulanceDriverProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = AmbulanceDriverProfile
        fields = '__all__'
        read_only_fields = ['user', 'last_location_update']


class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True, min_length=8)
    confirm_new_password = serializers.CharField(required=True)

    def validate(self, data):
        if data['new_password'] != data['confirm_new_password']:
            raise serializers.ValidationError({'confirm_new_password': 'New passwords do not match.'})
        return data
