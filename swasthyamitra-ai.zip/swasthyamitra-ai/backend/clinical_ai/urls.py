"""
Clinical AI — URL Configuration
"""
from django.urls import path
from . import views

urlpatterns = [
    path('symptom-checker/', views.SymptomCheckerAPIView.as_view(), name='symptom-checker'),
    path('predict-diabetes/', views.DiabetesPredictAPIView.as_view(), name='predict-diabetes'),
    path('predict-heart/', views.HeartPredictAPIView.as_view(), name='predict-heart'),
    path('analyze-report/', views.ReportAnalyzeAPIView.as_view(), name='analyze-report'),
]
