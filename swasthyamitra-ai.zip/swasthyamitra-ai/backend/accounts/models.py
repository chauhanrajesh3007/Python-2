"""
Accounts — Custom User Model & Role-Based Profiles

Supports three roles:
    PATIENT          — End user seeking healthcare
    DOCTOR           — Medical professional
    AMBULANCE_DRIVER — Emergency vehicle operator
"""
from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.core.validators import MinValueValidator, RegexValidator
from django.core.exceptions import ValidationError
from decimal import Decimal


class UserManager(BaseUserManager):
    """Custom manager that uses email as the unique identifier."""

    def _create_user(self, email, password, **extra_fields):
        if not email:
            raise ValueError('Email is required')
        email = self.normalize_email(email).strip().lower()
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', False)
        extra_fields.setdefault('is_superuser', False)
        return self._create_user(email, password, **extra_fields)

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('role', User.Role.ADMIN)
        return self._create_user(email, password, **extra_fields)


class User(AbstractUser):
    """
    Custom User model with role-based access.

    username is disabled — authentication happens via email.
    """

    class Role(models.TextChoices):
        PATIENT = 'PATIENT', 'Patient'
        DOCTOR = 'DOCTOR', 'Doctor'
        AMBULANCE_DRIVER = 'AMBULANCE_DRIVER', 'Ambulance Driver'
        ADMIN = 'ADMIN', 'Admin'

    # Disable the default username field
    username = None

    email = models.EmailField(
        'Email address',
        unique=True,
        db_index=True,
        error_messages={'unique': 'A user with this email already exists.'},
    )
    role = models.CharField(
        max_length=20,
        choices=Role.choices,
        default=Role.PATIENT,
        db_index=True,
    )
    first_name = models.CharField(max_length=100, blank=True)
    last_name = models.CharField(max_length=100, blank=True)
    phone = models.CharField(
        max_length=15,
        blank=True,
        validators=[RegexValidator(r'^\+?\d{7,15}$', 'Enter a valid phone number.')],
    )
    is_verified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name']

    objects = UserManager()

    class Meta:
        db_table = 'users'
        verbose_name = 'User'
        verbose_name_plural = 'Users'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.email} ({self.get_role_display()})'

    def clean(self):
        """Normalize and validate fields before saving."""
        super().clean()
        self.email = self.email.strip().lower() if self.email else self.email
        if self.first_name:
            self.first_name = self.first_name.strip()
        if self.last_name:
            self.last_name = self.last_name.strip()
        if self.phone:
            self.phone = self.phone.strip()

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)

    @property
    def full_name(self):
        return f'{self.first_name} {self.last_name}'.strip() or self.email


# ═══════════════════════════════════════════════════════════════════════════
# Profile Models
# ═══════════════════════════════════════════════════════════════════════════

class PatientProfile(models.Model):
    """Extended profile for PATIENT role users."""

    class Gender(models.TextChoices):
        MALE = 'MALE', 'Male'
        FEMALE = 'FEMALE', 'Female'

    BLOOD_GROUP_CHOICES = [
        ('A+', 'A+'), ('A-', 'A-'),
        ('B+', 'B+'), ('B-', 'B-'),
        ('AB+', 'AB+'), ('AB-', 'AB-'),
        ('O+', 'O+'), ('O-', 'O-'),
    ]

    user = models.OneToOneField(
        User, on_delete=models.CASCADE, related_name='patient_profile'
    )
    age = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1, 'Age must be at least 1')]
    )
    gender = models.CharField(
        max_length=6,
        choices=Gender.choices,
        db_index=True,
    )
    blood_group = models.CharField(
        max_length=3, choices=BLOOD_GROUP_CHOICES, blank=True, default=''
    )
    medical_history = models.TextField(
        blank=True, default='',
        help_text='Comma-separated chronic conditions, past surgeries, allergies, etc.'
    )
    address = models.TextField(blank=True, default='')
    city = models.CharField(max_length=100, blank=True, default='')
    state = models.CharField(max_length=100, blank=True, default='')
    pincode = models.CharField(max_length=10, blank=True, default='')
    emergency_contact_name = models.CharField(max_length=100, blank=True, default='')
    emergency_contact_phone = models.CharField(max_length=15, blank=True, default='')
    daily_ai_check_count = models.PositiveSmallIntegerField(default=0)
    last_ai_check_date = models.DateField(null=True, blank=True)

    class Meta:
        db_table = 'patient_profiles'
        verbose_name = 'Patient Profile'
        verbose_name_plural = 'Patient Profiles'

    def __str__(self):
        return f'Patient: {self.user.full_name}'

    def clean(self):
        if self.gender:
            self.gender = self.gender.upper()
        if self.age is not None and self.age <= 0:
            raise ValidationError({'age': 'Age must be greater than 0.'})


class DoctorProfile(models.Model):
    """Extended profile for DOCTOR role users."""

    user = models.OneToOneField(
        User, on_delete=models.CASCADE, related_name='doctor_profile'
    )
    specialization = models.CharField(max_length=150)
    clinic_hospital_name = models.CharField(max_length=250, blank=True, default='')
    registration_number = models.CharField(max_length=100, unique=True)
    years_of_experience = models.PositiveSmallIntegerField(default=0)
    consultation_fee = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        default=Decimal('199.00'),
        validators=[MinValueValidator(Decimal('0.00'))],
        help_text='Consultation fee in ₹'
    )
    bio = models.TextField(blank=True, default='')
    address = models.TextField(blank=True, default='')
    city = models.CharField(max_length=100, blank=True, default='')
    state = models.CharField(max_length=100, blank=True, default='')
    is_available_today = models.BooleanField(default=True)
    rating = models.DecimalField(max_digits=3, decimal_places=2, default=0.00)

    class Meta:
        db_table = 'doctor_profiles'
        verbose_name = 'Doctor Profile'
        verbose_name_plural = 'Doctor Profiles'

    def __str__(self):
        return f'Dr. {self.user.full_name} — {self.specialization}'


class DoctorAvailabilitySlot(models.Model):
    """Availability time-slot for a doctor."""

    DAY_CHOICES = [
        (0, 'Monday'),
        (1, 'Tuesday'),
        (2, 'Wednesday'),
        (3, 'Thursday'),
        (4, 'Friday'),
        (5, 'Saturday'),
        (6, 'Sunday'),
    ]

    doctor = models.ForeignKey(
        DoctorProfile, on_delete=models.CASCADE, related_name='availability_slots'
    )
    day_of_week = models.PositiveSmallIntegerField(choices=DAY_CHOICES)
    start_time = models.TimeField()
    end_time = models.TimeField()
    max_patients_per_slot = models.PositiveSmallIntegerField(default=5)

    class Meta:
        db_table = 'doctor_availability_slots'
        verbose_name = 'Doctor Availability Slot'
        verbose_name_plural = 'Doctor Availability Slots'
        ordering = ['day_of_week', 'start_time']

    def __str__(self):
        return f'{self.get_day_of_week_display()} {self.start_time}-{self.end_time}'


class AmbulanceDriverProfile(models.Model):
    """Extended profile for AMBULANCE_DRIVER role users."""

    user = models.OneToOneField(
        User, on_delete=models.CASCADE, related_name='ambulance_driver_profile'
    )
    vehicle_number = models.CharField(max_length=20, unique=True)
    vehicle_type = models.CharField(
        max_length=50,
        help_text='e.g., Basic Life Support, Advanced Life Support, Patient Transport'
    )
    current_latitude = models.DecimalField(
        max_digits=12, decimal_places=8, null=True, blank=True
    )
    current_longitude = models.DecimalField(
        max_digits=12, decimal_places=8, null=True, blank=True
    )
    is_available = models.BooleanField(default=True)
    phone = models.CharField(max_length=15, blank=True)
    city = models.CharField(max_length=100, blank=True)
    last_location_update = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'ambulance_driver_profiles'
        verbose_name = 'Ambulance Driver Profile'
        verbose_name_plural = 'Ambulance Driver Profiles'

    def __str__(self):
        return f'Ambulance Driver: {self.user.full_name} ({self.vehicle_number})'
