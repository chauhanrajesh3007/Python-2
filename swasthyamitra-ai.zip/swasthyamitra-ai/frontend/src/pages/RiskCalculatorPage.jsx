import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Loader2, Activity, ShieldAlert, ShieldCheck } from 'lucide-react';
import api from '../services/api';

const DIABETES_FIELDS = [
  { key: 'pregnancies', label: 'Pregnancies', placeholder: 'Number of times pregnant' },
  { key: 'glucose', label: 'Glucose Level (mg/dL)', placeholder: 'e.g., 148' },
  { key: 'blood_pressure', label: 'Blood Pressure (mm Hg)', placeholder: 'e.g., 72' },
  { key: 'skin_thickness', label: 'Skin Thickness (mm)', placeholder: 'e.g., 35' },
  { key: 'insulin', label: 'Insulin (mu U/ml)', placeholder: 'e.g., 0' },
  { key: 'bmi', label: 'BMI', placeholder: 'e.g., 33.6' },
  { key: 'diabetes_pedigree', label: 'Diabetes Pedigree Function', placeholder: 'e.g., 0.627' },
  { key: 'age', label: 'Age', placeholder: 'e.g., 50' },
];

const HEART_FIELDS = [
  { key: 'age', label: 'Age', placeholder: 'e.g., 61' },
  { key: 'sex', label: 'Sex (1=Male, 0=Female)', placeholder: '0 or 1' },
  { key: 'cp', label: 'Chest Pain Type (0-3)', placeholder: '0=typical, 1=atypical, 2=non-anginal, 3=asymptomatic' },
  { key: 'trestbps', label: 'Resting Blood Pressure', placeholder: 'e.g., 145' },
  { key: 'chol', label: 'Cholesterol (mg/dL)', placeholder: 'e.g., 233' },
  { key: 'fbs', label: 'Fasting Blood Sugar >120 (1/0)', placeholder: '1 if true' },
  { key: 'restecg', label: 'Resting ECG (0-2)', placeholder: 'e.g., 0' },
  { key: 'thalach', label: 'Max Heart Rate', placeholder: 'e.g., 150' },
  { key: 'exang', label: 'Exercise Angina (0/1)', placeholder: '1 if yes' },
  { key: 'oldpeak', label: 'ST Depression', placeholder: 'e.g., 2.3' },
  { key: 'slope', label: 'Slope of Peak ST (0-2)', placeholder: 'e.g., 0' },
  { key: 'ca', label: 'Major Vessels (0-3)', placeholder: 'e.g., 0' },
  { key: 'thal', label: 'Thalassemia (0-3)', placeholder: 'e.g., 1' },
];

export default function RiskCalculatorPage() {
  const [tab, setTab] = useState('diabetes');
  const [form, setForm] = useState({});
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fields = tab === 'diabetes' ? DIABETES_FIELDS : HEART_FIELDS;

  const handleChange = (key, val) => {
    setForm((prev) => ({ ...prev, [key]: val }));
  };

  const handleSubmit = async () => {
    setError('');
    setLoading(true);
    setResult(null);
    try {
      const url = tab === 'diabetes' ? '/ai/predict-diabetes/' : '/ai/predict-heart/';
      const res = await api.post(url, form);
      setResult(res.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Prediction failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 py-4">
        <div className="max-w-3xl mx-auto flex items-center gap-4">
          <Link to="/patient-dashboard" className="text-gray-500 hover:text-gray-700">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-lg font-semibold">Health Risk Calculator</h1>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-6">
        {/* Tab Switcher */}
        <div className="flex gap-2 mb-6">
          {['diabetes', 'heart'].map((t) => (
            <button
              key={t}
              onClick={() => { setTab(t); setResult(null); setForm({}); }}
              className={`flex-1 py-3 rounded-lg font-semibold text-sm transition-all
                ${tab === t ? 'bg-blue-600 text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200'}`}
            >
              {t === 'diabetes' ? '🩸 Diabetes Risk' : '❤️ Heart Disease Risk'}
            </button>
          ))}
        </div>

        {error && (
          <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">{error}</div>
        )}

        {/* Input Form */}
        <div className="card space-y-4">
          <h2 className="font-semibold text-lg">
            {tab === 'diabetes' ? 'Diabetes Risk Assessment' : 'Heart Disease Risk Assessment'}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {fields.map((f) => (
              <div key={f.key}>
                <label className="block text-xs font-medium text-gray-700 mb-1">{f.label}</label>
                <input
                  type="number"
                  step="any"
                  className="input-field text-sm"
                  placeholder={f.placeholder}
                  value={form[f.key] || ''}
                  onChange={(e) => handleChange(f.key, e.target.value)}
                />
              </div>
            ))}
          </div>
          <button onClick={handleSubmit} disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            {loading ? 'Calculating...' : 'Calculate Risk'}
          </button>
        </div>

        {/* Result */}
        {result && (
          <div className={`card mt-6 border-l-4 ${result.is_high_risk ? 'border-l-red-500' : 'border-l-green-500'}`}>
            <div className="flex items-center gap-3 mb-4">
              {result.is_high_risk ? (
                <ShieldAlert className="w-8 h-8 text-red-600" />
              ) : (
                <ShieldCheck className="w-8 h-8 text-green-600" />
              )}
              <div>
                <p className="text-sm text-gray-500">Risk Score</p>
                <p className={`text-3xl font-bold ${result.is_high_risk ? 'text-red-600' : 'text-green-600'}`}>
                  {result.risk_score_percent}%
                </p>
              </div>
            </div>
            <p className={`text-sm font-medium ${result.is_high_risk ? 'text-red-700' : 'text-green-700'}`}>
              {result.is_high_risk ? '⚠️ High Risk' : '✅ Low Risk'}
            </p>
            <p className="text-sm text-gray-600 mt-2">{result.recommendation}</p>
            {result.is_high_risk && (
              <Link to="/appointments" className="btn-primary mt-4 inline-flex">
                Consult {tab === 'diabetes' ? 'Endocrinologist' : 'Cardiologist'}
              </Link>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
