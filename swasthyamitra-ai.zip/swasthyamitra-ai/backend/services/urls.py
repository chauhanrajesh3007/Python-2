"""
Services — URL Configuration
"""
from django.urls import path
from . import views

urlpatterns = [
    # ── Appointments ──
    path('appointments/', views.AppointmentListCreateView.as_view(), name='appointment-list'),
    path('appointments/<int:pk>/', views.AppointmentDetailView.as_view(), name='appointment-detail'),
    path('appointments/<int:pk>/confirm-payment/', views.AppointmentConfirmPaymentView.as_view(), name='appointment-confirm'),

    # ── Medicine Reminders ──
    path('reminders/', views.ReminderListCreateView.as_view(), name='reminder-list'),
    path('reminders/<int:pk>/', views.ReminderDetailView.as_view(), name='reminder-detail'),

    # ── Ambulance ──
    path('nearest-ambulance/', views.NearestAmbulanceView.as_view(), name='nearest-ambulance'),
    path('ambulance-requests/', views.AmbulanceRequestView.as_view(), name='ambulance-requests'),
    path('update-location/', views.UpdateAmbulanceLocationView.as_view(), name='update-location'),

    # ── Subscriptions ──
    path('subscription/', views.SubscriptionView.as_view(), name='subscription'),
]
