"""
train_symptom.py — Train RandomForest classifier on the Prognosis/Symptoms dataset.

Dataset: Kaggle "Disease Symptom Prediction" (41 diseases, 132 binary symptoms)

Usage:
    python train_symptom.py

Outputs:
    clinical_ai/ml_models/symptom_rf.pkl
"""
import os
import sys
import pickle
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# Add the project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

MODEL_DIR = os.path.join(os.path.dirname(__file__), '..', 'ml_models')
os.makedirs(MODEL_DIR, exist_ok=True)

# ---------------------------------------------------------------------------
# 1. Load Dataset
# ---------------------------------------------------------------------------
# Expected columns: 132 symptom binary features + 'prognosis' (target label)
# Adjust the CSV path:
DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'datasets', 'symptoms_dataset.csv')

try:
    df = pd.read_csv(DATA_PATH)
    print(f'Loaded dataset: {df.shape[0]} rows × {df.shape[1]} columns')
except FileNotFoundError:
    print(f'Dataset not found at {DATA_PATH}')
    print('Please download from Kaggle: "Disease Symptom Prediction" dataset.')
    print('Place it at: clinical_ai/datasets/symptoms_dataset.csv')
    sys.exit(1)

# ---------------------------------------------------------------------------
# 2. Prepare Features & Labels
# ---------------------------------------------------------------------------
X = df.drop('prognosis', axis=1)
y = df['prognosis']

# Encode labels
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
y_encoded = le.fit_transform(y)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
)

# ---------------------------------------------------------------------------
# 3. Train Random Forest
# ---------------------------------------------------------------------------
model = RandomForestClassifier(
    n_estimators=100,
    max_depth=20,
    random_state=42,
    n_jobs=-1,
)
model.fit(X_train, y_train)

# ---------------------------------------------------------------------------
# 4. Evaluate
# ---------------------------------------------------------------------------
y_pred = model.predict(X_test)
acc = accuracy_score(y_test, y_pred)
print(f'\nTest Accuracy: {acc:.4f}')
print('\nClassification Report (top classes):')
print(classification_report(y_test, y_pred, target_names=le.classes_, zero_division=0))

# ---------------------------------------------------------------------------
# 5. Save Model + Metadata
# ---------------------------------------------------------------------------
model_artifact = {
    'model': model,
    'label_encoder': le,
    'feature_names': list(X.columns),
    'disease_names': list(le.classes_),
    'accuracy': acc,
}

output_path = os.path.join(MODEL_DIR, 'symptom_rf.pkl')
with open(output_path, 'wb') as f:
    pickle.dump(model_artifact, f)

print(f'\n✅ Model saved to: {output_path}')
