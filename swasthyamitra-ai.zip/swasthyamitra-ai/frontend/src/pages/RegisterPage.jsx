import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Heart, Loader2, User, Stethoscope, Truck } from 'lucide-react';

const ROLES = [
  { value: 'PATIENT', icon: User, label: 'Patient', desc: 'Get AI diagnosis & book appointments' },
  { value: 'DOCTOR', icon: Stethoscope, label: 'Doctor', desc: 'Manage patients & consultations' },
  { value: 'AMBULANCE_DRIVER', icon: Truck, label: 'Ambulance Driver', desc: 'Respond to emergencies' },
];

export default function RegisterPage() {
  const [step, setStep] = useState(1);
  const [role, setRole] = useState('PATIENT');
  const [form, setForm] = useState({ first_name: '', last_name: '', email: '', phone: '', password: '', confirm_password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirm_password) {
      setError('Passwords do not match.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const user = await register({ ...form, role });
      navigate(user.role === 'DOCTOR' ? '/doctor-dashboard' : '/patient-dashboard');
    } catch (err) {
      const data = err.response?.data;
      const msg = typeof data === 'object' ? Object.values(data).flat().join(', ') : 'Registration failed';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-2xl mb-4 shadow-lg">
            <Heart className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">SwasthyaMitra AI</h1>
          <p className="text-gray-600 mt-2">Create your account</p>
        </div>

        <form onSubmit={handleSubmit} className="card space-y-5">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">{error}</div>
          )}

          {/* Step 1: Choose Role */}
          {step === 1 && (
            <>
              <h2 className="text-lg font-semibold">I am a...</h2>
              <div className="space-y-2">
                {ROLES.map(({ value, icon: Icon, label, desc }) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => { setRole(value); setStep(2); }}
                    className={`w-full flex items-center gap-4 p-4 rounded-lg border-2 transition-all
                      ${role === value ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-300'}`}
                  >
                    <Icon className="w-6 h-6 text-blue-600" />
                    <div className="text-left">
                      <p className="font-semibold">{label}</p>
                      <p className="text-xs text-gray-500">{desc}</p>
                    </div>
                  </button>
                ))}
              </div>
            </>
          )}

          {/* Step 2: Details */}
          {step === 2 && (
            <>
              <div className="flex items-center gap-2">
                <button type="button" onClick={() => setStep(1)} className="text-sm text-blue-600 hover:underline">&larr; Change role</button>
                <span className="text-sm text-gray-400">|</span>
                <span className="text-sm font-medium">{role.replace('_', ' ')}</span>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">First Name</label>
                  <input className="input-field" required value={form.first_name} onChange={e => handleChange('first_name', e.target.value)} />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Last Name</label>
                  <input className="input-field" required value={form.last_name} onChange={e => handleChange('last_name', e.target.value)} />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Email</label>
                <input type="email" className="input-field" required value={form.email} onChange={e => handleChange('email', e.target.value)} />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Phone</label>
                <input type="tel" className="input-field" value={form.phone} onChange={e => handleChange('phone', e.target.value)} />
              </div>

              {/* Role-specific fields */}
              {role === 'PATIENT' && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Age</label>
                    <input type="number" className="input-field" required min={1} onChange={e => handleChange('age', e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Gender</label>
                    <select className="input-field" required onChange={e => handleChange('gender', e.target.value)}>
                      <option value="">Select</option>
                      <option value="MALE">Male</option>
                      <option value="FEMALE">Female</option>
                    </select>
                  </div>
                </div>
              )}
              {role === 'DOCTOR' && (
                <>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Specialization</label>
                    <input className="input-field" required onChange={e => handleChange('specialization', e.target.value)} placeholder="e.g., Cardiology" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1">Registration Number</label>
                    <input className="input-field" required onChange={e => handleChange('registration_number', e.target.value)} placeholder="e.g., GMC-2024-00123" />
                  </div>
                </>
              )}
              {role === 'AMBULANCE_DRIVER' && (
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Vehicle Number</label>
                  <input className="input-field" required onChange={e => handleChange('vehicle_number', e.target.value)} placeholder="e.g., GJ01AB1234" />
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Password</label>
                <input type="password" className="input-field" required minLength={8} value={form.password} onChange={e => handleChange('password', e.target.value)} />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Confirm Password</label>
                <input type="password" className="input-field" required value={form.confirm_password} onChange={e => handleChange('confirm_password', e.target.value)} />
              </div>

              <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                {loading ? 'Creating Account...' : 'Create Account'}
              </button>
            </>
          )}

          <p className="text-center text-sm text-gray-600">
            Already have an account?{' '}
            <Link to="/login" className="text-blue-600 hover:text-blue-800 font-medium">Sign In</Link>
          </p>
        </form>
      </div>
    </div>
  );
}
