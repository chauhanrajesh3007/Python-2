"""
Services — Appointment, Reminder, Ambulance & Subscription Views
"""
import math
from django.db.models import F
from django.conf import settings
from rest_framework import status, generics, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.decorators import action

from .models import Appointment, MedicineReminder, AmbulanceRequest, Subscription
from .serializers import (
    AppointmentSerializer, MedicineReminderSerializer,
    AmbulanceRequestSerializer, SubscriptionSerializer,
)
from accounts.models import AmbulanceDriverProfile

User = settings.AUTH_USER_MODEL


# ═══════════════════════════════════════════════════════════════════════════
# Helper — Haversine distance in km
# ═══════════════════════════════════════════════════════════════════════════

def haversine_km(lat1, lon1, lat2, lon2):
    """Calculate the great-circle distance between two coordinates in km."""
    R = 6371.0
    lat1, lon1 = math.radians(float(lat1)), math.radians(float(lon1))
    lat2, lon2 = math.radians(float(lat2)), math.radians(float(lon2))
    dlat, dlon = lat2 - lat1, lon2 - lon1
    a = math.sin(dlat / 2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def find_nearest_ambulance(user_lat, user_lon, max_radius_km=15):
    """
    Find the nearest available ambulance driver within max_radius_km.
    Returns (driver_profile, distance_km, eta_minutes) or (None, None, None).
    """
    available_drivers = AmbulanceDriverProfile.objects.filter(
        is_available=True,
        current_latitude__isnull=False,
        current_longitude__isnull=False,
    )

    best_driver = None
    best_distance = float('inf')

    for driver in available_drivers:
        dist = haversine_km(
            user_lat, user_lon,
            float(driver.current_latitude),
            float(driver.current_longitude),
        )
        if dist <= max_radius_km and dist < best_distance:
            best_distance = dist
            best_driver = driver

    if best_driver:
        # Estimate ETA: 30 km/h average in rural areas
        eta = round((best_distance / 30) * 60)
        return best_driver, round(best_distance, 2), max(eta, 5)
    return None, None, None


# ═══════════════════════════════════════════════════════════════════════════
# Appointments
# ═══════════════════════════════════════════════════════════════════════════

class AppointmentListCreateView(generics.ListCreateAPIView):
    """
    GET  /api/services/appointments/   — List my appointments
    POST /api/services/appointments/   — Book a new appointment
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = AppointmentSerializer

    def get_queryset(self):
        user = self.request.user
        if user.role == User.Role.PATIENT:
            return Appointment.objects.filter(patient=user).select_related('doctor')
        elif user.role == User.Role.DOCTOR:
            return Appointment.objects.filter(doctor=user).select_related('patient')
        return Appointment.objects.none()

    def perform_create(self, serializer):
        doctor = serializer.validated_data['doctor']
        fee = doctor.doctor_profile.consultation_fee
        serializer.save(
            patient=self.request.user,
            consultation_fee=fee,
            status=Appointment.Status.PENDING,
        )


class AppointmentDetailView(generics.RetrieveUpdateAPIView):
    """
    GET  /api/services/appointments/<id>/  — Appointment detail
    PATCH /api/services/appointments/<id>/  — Update status
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = AppointmentSerializer

    def get_queryset(self):
        user = self.request.user
        if user.role == User.Role.PATIENT:
            return Appointment.objects.filter(patient=user)
        return Appointment.objects.filter(doctor=user)


class AppointmentConfirmPaymentView(APIView):
    """
    POST /api/services/appointments/<id>/confirm-payment/
    Updates status from PENDING → PAID, generates video link.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        try:
            appointment = Appointment.objects.get(pk=pk, patient=request.user)
        except Appointment.DoesNotExist:
            return Response({'error': 'Appointment not found.'}, status=404)

        if appointment.status != Appointment.Status.PENDING:
            return Response({'error': 'Appointment is not in pending state.'}, status=400)

        appointment.status = Appointment.Status.PAID
        appointment.razorpay_payment_id = request.data.get('razorpay_payment_id', '')
        appointment.razorpay_order_id = request.data.get('razorpay_order_id', '')
        appointment.save()  # generates video_call_url automatically
        return Response(AppointmentSerializer(appointment).data)


# ═══════════════════════════════════════════════════════════════════════════
# Medicine Reminders
# ═══════════════════════════════════════════════════════════════════════════

class ReminderListCreateView(generics.ListCreateAPIView):
    """
    GET  /api/services/reminders/   — List my reminders
    POST /api/services/reminders/   — Create a new reminder
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = MedicineReminderSerializer

    def get_queryset(self):
        return MedicineReminder.objects.filter(
            patient=self.request.user, is_active=True
        )

    def perform_create(self, serializer):
        serializer.save(patient=self.request.user)


class ReminderDetailView(generics.RetrieveUpdateDestroyAPIView):
    """GET/PATCH/DELETE /api/services/reminders/<id>/"""
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = MedicineReminderSerializer

    def get_queryset(self):
        return MedicineReminder.objects.filter(patient=self.request.user)


# ═══════════════════════════════════════════════════════════════════════════
# Ambulance
# ═══════════════════════════════════════════════════════════════════════════

class NearestAmbulanceView(APIView):
    """
    POST /api/services/nearest-ambulance/
    Body: { "latitude": 23.0225, "longitude": 72.5714 }
    Finds the nearest available ambulance driver within 15 km.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        lat = request.data.get('latitude')
        lon = request.data.get('longitude')

        if lat is None or lon is None:
            return Response(
                {'error': 'latitude and longitude are required.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        driver, distance, eta = find_nearest_ambulance(float(lat), float(lon))

        if not driver:
            return Response({
                'found': False,
                'message': 'No ambulance available within 15 km. Please try emergency helpline — 108.',
            })

        return Response({
            'found': True,
            'driver': {
                'name': driver.user.full_name,
                'phone': driver.user.phone or driver.phone,
                'vehicle_number': driver.vehicle_number,
                'vehicle_type': driver.vehicle_type,
            },
            'distance_km': distance,
            'eta_minutes': eta,
        })


class AmbulanceRequestView(generics.ListCreateAPIView):
    """
    GET  /api/services/ambulance-requests/   — List my requests
    POST /api/services/ambulance-requests/   — Create emergency request
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = AmbulanceRequestSerializer

    def get_queryset(self):
        return AmbulanceRequest.objects.filter(patient=self.request.user)

    def perform_create(self, serializer):
        lat = serializer.validated_data.get('patient_latitude')
        lon = serializer.validated_data.get('patient_longitude')
        driver, distance, eta = find_nearest_ambulance(
            float(lat), float(lon)
        )
        serializer.save(
            patient=self.request.user,
            driver=driver.user if driver else None,
            driver_eta_minutes=eta if driver else None,
            status=AmbulanceRequest.Status.ACCEPTED if driver else AmbulanceRequest.Status.PENDING,
        )


class UpdateAmbulanceLocationView(APIView):
    """
    POST /api/services/update-location/
    Body: { "latitude": 23.0225, "longitude": 72.5714 }
    Updates the ambulance driver's current location.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        if request.user.role != User.Role.AMBULANCE_DRIVER:
            return Response({'error': 'Only ambulance drivers can update location.'}, status=403)

        lat = request.data.get('latitude')
        lon = request.data.get('longitude')
        if lat is None or lon is None:
            return Response({'error': 'latitude and longitude required.'}, status=400)

        try:
            profile = request.user.ambulance_driver_profile
            profile.current_latitude = lat
            profile.current_longitude = lon
            profile.save()
            return Response({'message': 'Location updated successfully.'})
        except AmbulanceDriverProfile.DoesNotExist:
            return Response({'error': 'Driver profile not found.'}, status=404)


# ═══════════════════════════════════════════════════════════════════════════
# Subscriptions
# ═══════════════════════════════════════════════════════════════════════════

class SubscriptionView(APIView):
    """
    GET  /api/services/subscription/   — Get subscription status
    POST /api/services/subscription/   — Upgrade to premium
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        try:
            sub = request.user.subscription
            return Response(SubscriptionSerializer(sub).data)
        except Subscription.DoesNotExist:
            # Auto-create free tier
            sub = Subscription.objects.create(patient=request.user)
            return Response(SubscriptionSerializer(sub).data)

    def post(self, request):
        try:
            sub = request.user.subscription
        except Subscription.DoesNotExist:
            sub = Subscription.objects.create(patient=request.user)

        if sub.tier == Subscription.Tier.PREMIUM:
            return Response({'message': 'Already on premium plan.'})

        sub.tier = Subscription.Tier.PREMIUM
        sub.razorpay_subscription_id = request.data.get('razorpay_subscription_id', '')
        sub.save()
        return Response({
            'message': 'Upgraded to premium! Unlimited AI checks unlocked.',
            'subscription': SubscriptionSerializer(sub).data,
        })
