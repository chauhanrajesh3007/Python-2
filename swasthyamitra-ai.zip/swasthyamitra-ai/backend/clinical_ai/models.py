"""
Clinical AI — ML prediction logs, report analyses
"""
from django.db import models
from django.conf import settings


class SymptomCheckResult(models.Model):
    """Stores the result of each symptom-checker run."""

    patient = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='symptom_checks',
    )
    symptoms_input = models.JSONField(
        help_text='Array of symptom names selected by the patient'
    )
    predictions = models.JSONField(
        help_text='Top 3 predicted diseases with confidence scores'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'symptom_check_results'
        verbose_name = 'Symptom Check Result'
        verbose_name_plural = 'Symptom Check Results'
        ordering = ['-created_at']

    def __str__(self):
        return f'Symptom check by {self.patient.full_name} on {self.created_at.date()}'


class RiskPredictionResult(models.Model):
    """Stores diabetes and heart disease risk predictions."""

    class PredictionType(models.TextChoices):
        DIABETES = 'DIABETES', 'Diabetes Risk'
        HEART = 'HEART', 'Heart Disease Risk'

    patient = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='risk_predictions',
    )
    prediction_type = models.CharField(max_length=15, choices=PredictionType.choices)
    input_data = models.JSONField(help_text='Raw form data submitted by patient')
    risk_score = models.DecimalField(
        max_digits=5, decimal_places=2, help_text='Percentage risk (0-100)'
    )
    is_high_risk = models.BooleanField(default=False)
    recommendation = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'risk_prediction_results'
        verbose_name = 'Risk Prediction Result'
        verbose_name_plural = 'Risk Prediction Results'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.get_prediction_type_display()} — {self.risk_score}%'


class MedicalReportAnalysis(models.Model):
    """Stores uploaded medical report analysis (X-Ray + Blood Report OCR)."""

    class AnalysisType(models.TextChoices):
        XRAY = 'XRAY', 'X-Ray / Medical Image'
        BLOOD_REPORT = 'BLOOD_REPORT', 'Blood Report OCR'

    patient = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='report_analyses',
    )
    report_file = models.FileField(upload_to='reports/%Y/%m/')
    analysis_type = models.CharField(max_length=15, choices=AnalysisType.choices)
    result_json = models.JSONField(help_text='Structured analysis output')
    summary = models.TextField(blank=True, help_text='Human-readable summary')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'medical_report_analyses'
        verbose_name = 'Medical Report Analysis'
        verbose_name_plural = 'Medical Report Analyses'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.get_analysis_type_display()} — {self.patient.full_name}'
