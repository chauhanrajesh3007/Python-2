import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Calendar, Clock, Video, User, FileText, LogOut, Heart } from 'lucide-react';
import api from '../services/api';

const STATUS_COLORS = {
  PENDING: 'bg-yellow-100 text-yellow-800',
  PAID: 'bg-green-100 text-green-800',
  IN_PROGRESS: 'bg-blue-100 text-blue-800',
  COMPLETED: 'bg-gray-100 text-gray-600',
  CANCELLED: 'bg-red-100 text-red-800',
};

export default function DoctorDashboard() {
  const { user, logout } = useAuth();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/services/appointments/')
      .then(r => setAppointments(r.data.results || r.data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const updateStatus = async (id, status) => {
    try {
      await api.patch(`/services/appointments/${id}/`, { status });
      setAppointments(prev => prev.map(a => a.id === id ? { ...a, status } : a));
    } catch (err) {
      alert('Update failed');
    }
  };

  const todayAppointments = appointments.filter(
    a => a.appointment_date === new Date().toISOString().split('T')[0]
  );
  const upcomingAppointments = appointments.filter(
    a => a.appointment_date > new Date().toISOString().split('T')[0]
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Heart className="w-8 h-8 text-blue-600" />
            <div>
              <h1 className="text-xl font-bold">SwasthyaMitra AI</h1>
              <p className="text-xs text-gray-500">Dr. {user?.first_name} {user?.last_name}</p>
            </div>
          </div>
          <button onClick={logout} className="text-gray-500 hover:text-red-600">
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        {loading ? (
          <div className="text-center py-12 text-gray-500">Loading appointments...</div>
        ) : (
          <div className="space-y-6">
            {/* Today's Appointments */}
            <div className="card">
              <h2 className="font-semibold text-lg flex items-center gap-2 mb-4">
                <Calendar className="w-5 h-5 text-blue-600" /> Today&apos;s Appointments ({todayAppointments.length})
              </h2>
              {todayAppointments.length === 0 ? (
                <p className="text-gray-500 text-sm">No appointments scheduled for today.</p>
              ) : (
                <div className="space-y-3">
                  {todayAppointments.map((a) => (
                    <AppointmentCard key={a.id} appointment={a} updateStatus={updateStatus} />
                  ))}
                </div>
              )}
            </div>

            {/* Upcoming */}
            <div className="card">
              <h2 className="font-semibold text-lg mb-4">
                Upcoming Appointments ({upcomingAppointments.length})
              </h2>
              {upcomingAppointments.length === 0 ? (
                <p className="text-gray-500 text-sm">No upcoming appointments.</p>
              ) : (
                <div className="space-y-3">
                  {upcomingAppointments.map((a) => (
                    <AppointmentCard key={a.id} appointment={a} updateStatus={updateStatus} />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function AppointmentCard({ appointment: a, updateStatus }) {
  return (
    <div className="p-4 bg-gray-50 rounded-lg border border-gray-200 flex flex-wrap items-center justify-between gap-3">
      <div>
        <div className="flex items-center gap-2">
          <User className="w-4 h-4 text-gray-500" />
          <span className="font-medium">{a.patient_name || `Patient #${a.patient}`}</span>
        </div>
        <div className="flex items-center gap-3 text-sm text-gray-500 mt-1">
          <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {a.slot_start_time} — {a.slot_end_time}</span>
          <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {a.appointment_date}</span>
        </div>
        {a.symptoms_summary && (
          <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
            <FileText className="w-3 h-3" /> {a.symptoms_summary}
          </p>
        )}
      </div>
      <div className="flex items-center gap-2">
        <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${STATUS_COLORS[a.status]}`}>
          {a.status}
        </span>
        {a.status === 'PAID' && (
          <button onClick={() => updateStatus(a.id, 'IN_PROGRESS')}
                  className="bg-blue-600 text-white text-xs px-3 py-1.5 rounded-lg hover:bg-blue-700">
            Start
          </button>
        )}
        {a.status === 'IN_PROGRESS' && (
          <button onClick={() => updateStatus(a.id, 'COMPLETED')}
                  className="bg-green-600 text-white text-xs px-3 py-1.5 rounded-lg hover:bg-green-700">
            Complete
          </button>
        )}
        {a.video_call_url && (
          <a href={a.video_call_url} target="_blank" rel="noopener noreferrer"
             className="flex items-center gap-1 text-blue-600 hover:text-blue-800 text-xs font-medium">
            <Video className="w-3 h-3" /> Join Call
          </a>
        )}
      </div>
    </div>
  );
}
