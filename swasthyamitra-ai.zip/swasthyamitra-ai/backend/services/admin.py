"""
Services — Django Admin Registration
"""
from django.contrib import admin
from .models import Appointment, MedicineReminder, AmbulanceRequest, Subscription


@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ['patient', 'doctor', 'appointment_date', 'slot_start_time', 'status']
    list_filter = ['status', 'appointment_date']
    search_fields = ['patient__email', 'doctor__email']


@admin.register(MedicineReminder)
class MedicineReminderAdmin(admin.ModelAdmin):
    list_display = ['patient', 'medicine_name', 'scheduled_time', 'is_active']
    list_filter = ['is_active']


@admin.register(AmbulanceRequest)
class AmbulanceRequestAdmin(admin.ModelAdmin):
    list_display = ['patient', 'driver', 'status', 'created_at']
    list_filter = ['status']


@admin.register(Subscription)
class SubscriptionAdmin(admin.ModelAdmin):
    list_display = ['patient', 'tier', 'is_active', 'end_date']
    list_filter = ['tier', 'is_active']
