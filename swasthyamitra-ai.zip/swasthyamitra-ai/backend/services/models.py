"""
Services — Appointments, Reminders, Ambulance, Subscriptions
"""
from django.db import models
from django.conf import settings
from django.core.validators import MinValueValidator, MaxValueValidator
from decimal import Decimal


def _patient_limit():
    return {'role': 'PATIENT'}


def _doctor_limit():
    return {'role': 'DOCTOR'}


def _driver_limit():
    return {'role': 'AMBULANCE_DRIVER'}


class Appointment(models.Model):
    """
    Doctor appointment booking linking Patient <-> Doctor.
    """

    class Status(models.TextChoices):
        PENDING = 'PENDING', 'Pending Payment'
        PAID = 'PAID', 'Paid — Confirmed'
        IN_PROGRESS = 'IN_PROGRESS', 'Consultation In Progress'
        COMPLETED = 'COMPLETED', 'Completed'
        CANCELLED = 'CANCELLED', 'Cancelled'

    patient = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='patient_appointments',
        limit_choices_to=_patient_limit,
    )
    doctor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='doctor_appointments',
        limit_choices_to=_doctor_limit,
    )
    appointment_date = models.DateField(db_index=True)
    slot_start_time = models.TimeField()
    slot_end_time = models.TimeField()
    status = models.CharField(
        max_length=15,
        choices=Status.choices,
        default=Status.PENDING,
        db_index=True,
    )
    symptoms_summary = models.TextField(
        blank=True,
        help_text='Pre-filled from AI symptom checker'
    )
    doctor_notes = models.TextField(blank=True)
    consultation_fee = models.DecimalField(
        max_digits=8, decimal_places=2, default=Decimal('199.00')
    )
    razorpay_order_id = models.CharField(max_length=100, blank=True)
    razorpay_payment_id = models.CharField(max_length=100, blank=True)
    video_call_url = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'appointments'
        verbose_name = 'Appointment'
        verbose_name_plural = 'Appointments'
        ordering = ['-appointment_date', 'slot_start_time']
        constraints = [
            models.UniqueConstraint(
                fields=['doctor', 'appointment_date', 'slot_start_time'],
                name='unique_doctor_slot',
            )
        ]

    def __str__(self):
        return f'{self.patient.full_name} ↔ Dr. {self.doctor.full_name} on {self.appointment_date}'

    def generate_video_link(self):
        """Generate a Jitsi Meet link unique to this appointment."""
        self.video_call_url = (
            f'{settings.JITSI_BASE_URL}SwasthyaMitra_Appointment_{self.id}'
        )
        return self.video_call_url

    def save(self, *args, **kwargs):
        if self.status == self.Status.PAID and not self.video_call_url:
            self.generate_video_link()
        super().save(*args, **kwargs)


class MedicineReminder(models.Model):
    """
    Medicine reminder with scheduled WhatsApp notification.
    """

    patient = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='medicine_reminders',
        limit_choices_to=_patient_limit,
    )
    medicine_name = models.CharField(max_length=200)
    dosage = models.CharField(
        max_length=100,
        help_text='e.g., "1 tablet", "5ml syrup", "2 capsules"'
    )
    scheduled_time = models.TimeField(
        help_text='Time of day to take the medicine (e.g., 09:00:00)'
    )
    frequency = models.CharField(
        max_length=50,
        help_text='e.g., "Once daily", "Twice daily", "Every 8 hours"'
    )
    start_date = models.DateField()
    end_date = models.DateField()
    phone_number = models.CharField(
        max_length=15,
        help_text='WhatsApp number with country code'
    )
    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)
    last_sent_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'medicine_reminders'
        verbose_name = 'Medicine Reminder'
        verbose_name_plural = 'Medicine Reminders'
        ordering = ['scheduled_time']

    def __str__(self):
        return f'{self.medicine_name} — {self.patient.full_name} at {self.scheduled_time}'


class AmbulanceRequest(models.Model):
    """
    Emergency ambulance dispatch request.
    """

    class Status(models.TextChoices):
        PENDING = 'PENDING', 'Searching for Driver'
        ACCEPTED = 'ACCEPTED', 'Driver Assigned'
        EN_ROUTE = 'EN_ROUTE', 'Ambulance On The Way'
        ARRIVED = 'ARRIVED', 'Ambulance Arrived'
        COMPLETED = 'COMPLETED', 'Trip Completed'
        CANCELLED = 'CANCELLED', 'Cancelled'

    patient = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='ambulance_requests',
    )
    driver = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='ambulance_assignments',
        limit_choices_to=_driver_limit,
    )
    patient_latitude = models.DecimalField(max_digits=12, decimal_places=8)
    patient_longitude = models.DecimalField(max_digits=12, decimal_places=8)
    pickup_address = models.TextField(blank=True)
    medical_notes = models.TextField(blank=True)
    status = models.CharField(
        max_length=15,
        choices=Status.choices,
        default=Status.PENDING,
        db_index=True,
    )
    driver_eta_minutes = models.PositiveSmallIntegerField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'ambulance_requests'
        verbose_name = 'Ambulance Request'
        verbose_name_plural = 'Ambulance Requests'
        ordering = ['-created_at']

    def __str__(self):
        return f'Emergency — {self.patient.full_name} ({self.status})'


class Subscription(models.Model):
    """
    AI premium subscription tracker.
    """

    class Tier(models.TextChoices):
        FREE = 'FREE', 'Free — 3 AI checks/day'
        PREMIUM = 'PREMIUM', 'Premium — Unlimited AI checks'

    patient = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='subscription',
        limit_choices_to=_patient_limit,
    )
    tier = models.CharField(
        max_length=10,
        choices=Tier.choices,
        default=Tier.FREE,
    )
    monthly_fee = models.DecimalField(
        max_digits=8, decimal_places=2, default=Decimal('499.00')
    )
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    razorpay_subscription_id = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'subscriptions'
        verbose_name = 'Subscription'
        verbose_name_plural = 'Subscriptions'

    def __str__(self):
        return f'{self.patient.full_name} — {self.tier}'
