import { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Upload, Loader2, FileImage, FileText, AlertCircle, CheckCircle2, XCircle } from 'lucide-react';
import api from '../services/api';

export default function ReportAnalyzerPage() {
  const [file, setFile] = useState(null);
  const [reportType, setReportType] = useState('XRAY');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef();

  const handleFileDrop = (e) => {
    e.preventDefault();
    const f = e.dataTransfer?.files?.[0] || e.target.files?.[0];
    if (f) setFile(f);
  };

  const handleAnalyze = async () => {
    if (!file) { setError('Please upload a file.'); return; }
    setError('');
    setLoading(true);
    setResult(null);
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('report_type', reportType);
      const res = await api.post('/ai/analyze-report/', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setResult(res.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Analysis failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 py-4">
        <div className="max-w-3xl mx-auto flex items-center gap-4">
          <Link to="/patient-dashboard" className="text-gray-500 hover:text-gray-700">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-lg font-semibold">Medical Report Analyzer</h1>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-6">
        {error && (
          <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center gap-2">
            <AlertCircle className="w-4 h-4" /> {error}
          </div>
        )}

        <div className="card space-y-4">
          {/* Report Type Selector */}
          <div className="flex gap-2">
            {[
              { value: 'XRAY', icon: FileImage, label: 'X-Ray / Scan' },
              { value: 'BLOOD_REPORT', icon: FileText, label: 'Blood Report' },
            ].map(({ value, icon: Icon, label }) => (
              <button
                key={value}
                onClick={() => { setReportType(value); setResult(null); }}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg font-medium text-sm transition-all
                  ${reportType === value ? 'bg-blue-600 text-white shadow-md' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
              >
                <Icon className="w-4 h-4" /> {label}
              </button>
            ))}
          </div>

          {/* Drop Zone */}
          <div
            onDrop={handleFileDrop}
            onDragOver={(e) => e.preventDefault()}
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-gray-300 rounded-xl p-10 text-center cursor-pointer
                       hover:border-blue-400 hover:bg-blue-50 transition-all duration-200"
          >
            <Upload className="w-10 h-10 text-gray-400 mx-auto mb-3" />
            {file ? (
              <div>
                <p className="font-medium text-blue-600">{file.name}</p>
                <p className="text-sm text-gray-500">{(file.size / 1024).toFixed(1)} KB — Click to change</p>
              </div>
            ) : (
              <div>
                <p className="font-medium text-gray-700">Drag &amp; drop your file here</p>
                <p className="text-sm text-gray-500 mt-1">or click to browse</p>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              className="hidden"
              accept="image/*,.pdf"
              onChange={handleFileDrop}
            />
          </div>

          <button onClick={handleAnalyze} disabled={loading || !file} className="btn-primary w-full flex items-center justify-center gap-2">
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            {loading ? 'Analyzing...' : 'Analyze Report'}
          </button>
        </div>

        {/* Results */}
        {result && (
          <div className="card mt-6 space-y-4">
            <h2 className="font-semibold text-lg flex items-center gap-2">
              {result.analysis_type === 'XRAY' ? <FileImage className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
              Analysis Results
            </h2>

            {/* Summary */}
            <div className={`p-4 rounded-lg ${result.result?.is_abnormal ? 'bg-red-50 border border-red-200' : 'bg-green-50 border border-green-200'}`}>
              <p className={`font-medium ${result.result?.is_abnormal ? 'text-red-700' : 'text-green-700'}`}>
                {result.summary}
              </p>
            </div>

            {/* Blood Report — Parameters Table */}
            {result.analysis_type === 'BLOOD_REPORT' && result.result?.parameters && Object.keys(result.result.parameters).length > 0 && (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-2 font-medium">Parameter</th>
                      <th className="text-left py-2 font-medium">Value</th>
                      <th className="text-left py-2 font-medium">Reference Range</th>
                      <th className="text-left py-2 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(result.result.parameters).map(([key, val]) => (
                      <tr key={key} className="border-b border-gray-100">
                        <td className="py-2 font-medium uppercase">{key}</td>
                        <td className="py-2">{val.value} {val.unit}</td>
                        <td className="py-2 text-gray-500">{val.reference_range}</td>
                        <td className="py-2">
                          {val.status === 'normal' ? (
                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                          ) : (
                            <span className="text-red-600 font-medium text-xs flex items-center gap-1">
                              <XCircle className="w-3 h-3" /> {val.status.toUpperCase()}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Abnormal Flags */}
            {result.result?.abnormal_flags?.length > 0 && (
              <div className="p-4 bg-red-50 rounded-lg">
                <h3 className="font-medium text-red-700 mb-2">⚠️ Abnormal Findings</h3>
                <ul className="list-disc list-inside text-sm text-red-600 space-y-1">
                  {result.result.abnormal_flags.map((f, i) => <li key={i}>{f}</li>)}
                </ul>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
