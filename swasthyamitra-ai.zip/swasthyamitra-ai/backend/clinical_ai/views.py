"""
Clinical AI — Symptom Checker, Risk Predictors, Report Analyzer
"""
import os
import json
import datetime
import logging
from django.conf import settings
from django.core.files.storage import default_storage
from rest_framework import status, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import SymptomCheckResult, RiskPredictionResult, MedicalReportAnalysis

logger = logging.getLogger(__name__)


def _check_ai_limit(user):
    """
    Enforce daily AI check limit for free-tier users.
    Returns (allowed: bool, message: str).
    """
    from services.models import Subscription
    try:
        sub = user.subscription
        is_premium = sub.tier == Subscription.Tier.PREMIUM and sub.is_active
    except Subscription.DoesNotExist:
        is_premium = False

    if is_premium:
        return True, ''

    try:
        profile = user.patient_profile
    except Exception:
        return True, ''  # Non-patient users bypass limit

    today = datetime.date.today()
    if profile.last_ai_check_date != today:
        profile.daily_ai_check_count = 0
        profile.last_ai_check_date = today
        profile.save()

    if profile.daily_ai_check_count >= settings.DAILY_AI_CHECK_LIMIT_FREE:
        return False, (
            f'You have reached your daily limit of {settings.DAILY_AI_CHECK_LIMIT_FREE} '
            f'free AI checks. Upgrade to Premium (₹499/month) for unlimited access.'
        )

    profile.daily_ai_check_count += 1
    profile.save()
    return True, ''


# ═══════════════════════════════════════════════════════════════════════════
# Symptom Checker
# ═══════════════════════════════════════════════════════════════════════════

class SymptomCheckerAPIView(APIView):
    """
    POST /api/ai/symptom-checker/

    Body: { "symptoms": ["fever", "headache", "cough", ...] }

    Maps symptoms to a binary feature vector, runs a RandomForest classifier,
    and returns the top 3 predicted diseases with confidence scores.
    """

    permission_classes = [permissions.IsAuthenticated]

    # The full set of 132 symptoms the model was trained on (in order).
    # In production, these are loaded from the trained model's metadata.
    SYMPTOM_FEATURES = [
        'itching', 'skin_rash', 'nodal_skin_eruptions', 'continuous_sneezing',
        'shivering', 'chills', 'joint_pain', 'stomach_pain', 'acidity',
        'ulcers_on_tongue', 'muscle_wasting', 'vomiting', 'burning_micturition',
        'spotting_urination', 'fatigue', 'weight_gain', 'anxiety',
        'cold_hands_and_feets', 'mood_swings', 'weight_loss', 'restlessness',
        'lethargy', 'patches_in_throat', 'irregular_sugar_level', 'cough',
        'high_fever', 'sunken_eyes', 'breathlessness', 'sweating',
        'dehydration', 'indigestion', 'headache', 'yellowish_skin',
        'dark_urine', 'nausea', 'loss_of_appetite', 'pain_behind_the_eyes',
        'back_pain', 'constipation', 'abdominal_pain', 'diarrhoea',
        'mild_fever', 'yellow_urine', 'yellowing_of_eyes',
        'acute_liver_failure', 'fluid_overload', 'swelling_of_stomach',
        'swelled_lymph_nodes', 'malaise', 'blurred_and_distorted_vision',
        'phlegm', 'throat_irritation', 'redness_of_eyes', 'sinus_pressure',
        'runny_nose', 'congestion', 'chest_pain', 'weakness_in_limbs',
        'fast_heart_rate', 'pain_during_bowel_movements',
        'pain_in_anal_region', 'bloody_stool', 'irritation_in_anus',
        'neck_pain', 'dizziness', 'cramps', 'bruising', 'obesity',
        'swollen_legs', 'swollen_blood_vessels', 'puffy_face_and_eyes',
        'enlarged_thyroid', 'brittle_nails', 'swollen_extremeties',
        'excessive_hunger', 'extra_marital_contacts',
        'drying_and_tingling_lips', 'slurred_speech', 'knee_pain',
        'hip_joint_pain', 'muscle_weakness', 'stiff_neck',
        'swelling_joints', 'movement_stiffness', 'spinning_movements',
        'loss_of_balance', 'unsteadiness', 'weakness_of_one_body_side',
        'loss_of_smell', 'bladder_discomfort', 'foul_smell_of_urine',
        'continuous_feel_of_urine', 'passage_of_gases', 'internal_itching',
        'toxic_look_(typhos)', 'depression', 'irritability', 'muscle_pain',
        'altered_sensorium', 'red_spots_over_body', 'belly_pain',
        'abnormal_menstruation', 'dischromic_patches', 'watering_from_eyes',
        'increased_appetite', 'polyuria', 'family_history', 'mucoid_sputum',
        'rusty_sputum', 'lack_of_concentration', 'visual_disturbances',
        'receiving_blood_transfusion', 'receiving_unsterile_injections',
        'coma', 'stomach_bleeding', 'distention_of_abdomen',
        'history_of_alcohol_consumption', 'fluid_overload.1',
        'blood_in_sputum', 'prominent_veins_on_calf', 'palpitations',
        'painful_walking', 'pus_filled_pimples', 'blackheads', 'scurring',
        'skin_peeling', 'silver_like_dusting', 'small_dents_in_nails',
        'inflammatory_nails', 'blister', 'red_sore_around_nose',
        'yellow_crust_ooze',
    ]

    # Top diseases the model can predict
    DISEASES = [
        'Fungal infection', 'Allergy', 'GERD', 'Chronic cholestasis',
        'Drug Reaction', 'Peptic ulcer diseae', 'AIDS',
        'Diabetes', 'Gastroenteritis', 'Bronchial Asthma',
        'Hypertension', 'Migraine', 'Cervical spondylosis',
        'Paralysis (brain hemorrhage)', 'Jaundice', 'Malaria',
        'Chicken pox', 'Dengue', 'Typhoid', 'hepatitis A',
        'Hepatitis B', 'Hepatitis C', 'Hepatitis D', 'Hepatitis E',
        'Alcoholic hepatitis', 'Tuberculosis', 'Common Cold',
        'Pneumonia', 'Dimorphic hemmorhoids(piles)',
        'Heart attack', 'Varicose veins', 'Hypothyroidism',
        'Hyperthyroidism', 'Hypoglycemia', 'Osteoarthristis',
        'Arthritis', '(vertigo) Paroymsal  Positional Vertigo',
        'Acne', 'Urinary tract infection', 'Psoriasis', 'Impetigo',
    ]

    def post(self, request):
        # Rate limit
        allowed, limit_msg = _check_ai_limit(request.user)
        if not allowed:
            return Response({'error': limit_msg}, status=status.HTTP_403_FORBIDDEN)

        symptoms = request.data.get('symptoms', [])
        if not symptoms or not isinstance(symptoms, list):
            return Response(
                {'error': 'Provide a "symptoms" array.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Build binary feature vector
        feature_vector = [0] * len(self.SYMPTOM_FEATURES)
        unknown = []
        for sym in symptoms:
            sym_key = sym.lower().strip().replace(' ', '_').replace('-', '_')
            try:
                idx = self.SYMPTOM_FEATURES.index(sym_key)
                feature_vector[idx] = 1
            except ValueError:
                unknown.append(sym)

        # Try to load the trained model; fall back to rule-based simulation
        predictions = self._predict(feature_vector, symptoms)

        # Persist result
        SymptomCheckResult.objects.create(
            patient=request.user,
            symptoms_input=symptoms,
            predictions=predictions,
        )

        return Response({
            'symptoms_recognized': [s for s in symptoms if s not in unknown],
            'symptoms_unknown': unknown,
            'predictions': predictions,
            'recommendation': (
                'Please consult a specialist doctor for a confirmed diagnosis. '
                'Book an appointment through the SwasthyaMitra AI platform.'
            ),
        })

    def _predict(self, feature_vector, symptoms):
        """
        Run prediction. Tries to load a trained RandomForest model;
        falls back to a keyword-based heuristic for demo/development.
        """
        # ── Attempt to load the real model ──
        import pickle
        model_path = os.path.join(
            settings.BASE_DIR, 'clinical_ai', 'ml_models', 'symptom_rf.pkl'
        )
        try:
            if os.path.exists(model_path):
                with open(model_path, 'rb') as f:
                    model = pickle.load(f)
                probs = model.predict_proba([feature_vector])[0]
                top_indices = probs.argsort()[-3:][::-1]
                return [
                    {
                        'disease': self.DISEASES[i] if i < len(self.DISEASES) else f'Class_{i}',
                        'confidence': round(float(probs[i]) * 100, 1),
                    }
                    for i in top_indices
                ]
        except Exception as e:
            logger.warning(f'Model load failed, using heuristic: {e}')

        # ── Heuristic fallback ──
        symptom_keywords = ' '.join(symptoms).lower()
        results = [
            {'disease': 'Common Cold', 'confidence': 45.0},
            {'disease': 'Migraine', 'confidence': 25.0},
            {'disease': 'Allergy', 'confidence': 18.0},
        ]
        if 'chest_pain' in symptom_keywords or 'breathlessness' in symptom_keywords:
            results = [
                {'disease': 'Hypertension', 'confidence': 55.0},
                {'disease': 'Heart attack', 'confidence': 25.0},
                {'disease': 'Bronchial Asthma', 'confidence': 20.0},
            ]
        elif 'fever' in symptom_keywords and 'headache' in symptom_keywords:
            results = [
                {'disease': 'Dengue', 'confidence': 40.0},
                {'disease': 'Malaria', 'confidence': 32.0},
                {'disease': 'Typhoid', 'confidence': 28.0},
            ]
        elif 'joint_pain' in symptom_keywords or 'muscle_pain' in symptom_keywords:
            results = [
                {'disease': 'Arthritis', 'confidence': 48.0},
                {'disease': 'Osteoarthristis', 'confidence': 30.0},
                {'disease': 'Cervical spondylosis', 'confidence': 22.0},
            ]
        return results


# ═══════════════════════════════════════════════════════════════════════════
# Diabetes Risk Predictor
# ═══════════════════════════════════════════════════════════════════════════

class DiabetesPredictAPIView(APIView):
    """
    POST /api/ai/predict-diabetes/

    Body: {
        "pregnancies": 2,
        "glucose": 148,
        "blood_pressure": 72,
        "skin_thickness": 35,
        "insulin": 0,
        "bmi": 33.6,
        "diabetes_pedigree": 0.627,
        "age": 50
    }
    """

    permission_classes = [permissions.IsAuthenticated]

    REQUIRED_FIELDS = [
        'pregnancies', 'glucose', 'blood_pressure',
        'skin_thickness', 'insulin', 'bmi', 'diabetes_pedigree', 'age',
    ]

    def post(self, request):
        allowed, limit_msg = _check_ai_limit(request.user)
        if not allowed:
            return Response({'error': limit_msg}, status=status.HTTP_403_FORBIDDEN)

        # Validate inputs
        data = {}
        for field in self.REQUIRED_FIELDS:
            if field not in request.data:
                return Response(
                    {'error': f'Missing required field: {field}'},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            try:
                data[field] = float(request.data[field])
            except (ValueError, TypeError):
                return Response(
                    {'error': f'Invalid numeric value for: {field}'},
                    status=status.HTTP_400_BAD_REQUEST,
                )

        risk_score = self._predict_risk(data)

        high_risk = risk_score >= 50.0
        recommendation = (
            'High risk of diabetes detected. Please consult an endocrinologist immediately.'
            if high_risk
            else 'Your risk appears low, but maintain a healthy lifestyle and regular check-ups.'
        )

        RiskPredictionResult.objects.create(
            patient=request.user,
            prediction_type=RiskPredictionResult.PredictionType.DIABETES,
            input_data=data,
            risk_score=risk_score,
            is_high_risk=high_risk,
            recommendation=recommendation,
        )

        return Response({
            'risk_score_percent': risk_score,
            'is_high_risk': high_risk,
            'inputs': data,
            'recommendation': recommendation,
        })

    def _predict_risk(self, data):
        """Run prediction; falls back to heuristic if model unavailable."""
        import pickle
        model_path = os.path.join(
            settings.BASE_DIR, 'clinical_ai', 'ml_models', 'diabetes_model.pkl'
        )
        try:
            if os.path.exists(model_path):
                with open(model_path, 'rb') as f:
                    model = pickle.load(f)
                features = [[
                    data['pregnancies'], data['glucose'], data['blood_pressure'],
                    data['skin_thickness'], data['insulin'], data['bmi'],
                    data['diabetes_pedigree'], data['age'],
                ]]
                prob = model.predict_proba(features)[0][1] * 100
                return round(float(prob), 2)
        except Exception as e:
            logger.warning(f'Diabetes model load failed, using heuristic: {e}')

        # Heuristic
        score = 0
        if data['glucose'] > 140:
            score += 40
        elif data['glucose'] > 100:
            score += 20
        if data['bmi'] > 30:
            score += 25
        elif data['bmi'] > 25:
            score += 12
        if data['age'] > 45:
            score += 15
        if data['diabetes_pedigree'] > 0.5:
            score += 20
        return round(min(score, 95.0), 2)


# ═══════════════════════════════════════════════════════════════════════════
# Heart Disease Predictor
# ═══════════════════════════════════════════════════════════════════════════

class HeartPredictAPIView(APIView):
    """
    POST /api/ai/predict-heart/

    Body: {
        "age": 61,
        "sex": 1,
        "cp": 3,        (chest pain type: 0-3)
        "trestbps": 145, (resting blood pressure)
        "chol": 233,    (cholesterol)
        "fbs": 1,       (fasting blood sugar > 120: 1/0)
        "restecg": 0,   (resting ECG: 0-2)
        "thalach": 150, (max heart rate)
        "exang": 0,     (exercise angina: 0/1)
        "oldpeak": 2.3, (ST depression)
        "slope": 0,     (slope of peak ST: 0-2)
        "ca": 0,        (major vessels colored: 0-3)
        "thal": 1       (thalassemia: 0-3)
    }
    """

    permission_classes = [permissions.IsAuthenticated]

    REQUIRED_FIELDS = [
        'age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg',
        'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal',
    ]

    CP_LABELS = {0: 'Typical Angina', 1: 'Atypical Angina', 2: 'Non-anginal Pain', 3: 'Asymptomatic'}

    def post(self, request):
        allowed, limit_msg = _check_ai_limit(request.user)
        if not allowed:
            return Response({'error': limit_msg}, status=status.HTTP_403_FORBIDDEN)

        data = {}
        for field in self.REQUIRED_FIELDS:
            if field not in request.data:
                return Response(
                    {'error': f'Missing required field: {field}'},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            try:
                data[field] = float(request.data[field])
            except (ValueError, TypeError):
                return Response(
                    {'error': f'Invalid numeric value for: {field}'},
                    status=status.HTTP_400_BAD_REQUEST,
                )

        risk_score = self._predict_risk(data)

        high_risk = risk_score >= 50.0
        recommendation = (
            'High risk of heart disease detected. Please consult a cardiologist urgently.'
            if high_risk
            else 'Your heart disease risk appears low. Maintain a heart-healthy lifestyle.'
        )

        RiskPredictionResult.objects.create(
            patient=request.user,
            prediction_type=RiskPredictionResult.PredictionType.HEART,
            input_data=data,
            risk_score=risk_score,
            is_high_risk=high_risk,
            recommendation=recommendation,
        )

        return Response({
            'risk_score_percent': risk_score,
            'is_high_risk': high_risk,
            'inputs': data,
            'recommendation': recommendation,
        })

    def _predict_risk(self, data):
        import pickle
        model_path = os.path.join(
            settings.BASE_DIR, 'clinical_ai', 'ml_models', 'heart_model.pkl'
        )
        try:
            if os.path.exists(model_path):
                with open(model_path, 'rb') as f:
                    model = pickle.load(f)
                features = [[
                    data['age'], data['sex'], data['cp'], data['trestbps'],
                    data['chol'], data['fbs'], data['restecg'], data['thalach'],
                    data['exang'], data['oldpeak'], data['slope'], data['ca'], data['thal'],
                ]]
                prob = model.predict_proba(features)[0][1] * 100
                return round(float(prob), 2)
        except Exception as e:
            logger.warning(f'Heart model load failed, using heuristic: {e}')

        # Heuristic
        score = 0
        if data['age'] > 55:
            score += 20
        if data['sex'] == 1:
            score += 10
        if data['cp'] >= 2:
            score += 15
        if data['trestbps'] > 140:
            score += 15
        if data['chol'] > 240:
            score += 20
        if data['thalach'] < 120:
            score += 10
        if data['exang'] == 1:
            score += 10
        return round(min(score, 95.0), 2)


# ═══════════════════════════════════════════════════════════════════════════
# Medical Report Analyzer (X-Ray CNN + Blood Report OCR)
# ═══════════════════════════════════════════════════════════════════════════

class ReportAnalyzeAPIView(APIView):
    """
    POST /api/ai/analyze-report/

    Multipart form-data:
        file:        The uploaded image/PDF
        report_type: "XRAY" or "BLOOD_REPORT"
    """

    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        allowed, limit_msg = _check_ai_limit(request.user)
        if not allowed:
            return Response({'error': limit_msg}, status=status.HTTP_403_FORBIDDEN)

        uploaded_file = request.FILES.get('file')
        report_type = request.data.get('report_type', 'XRAY').upper()

        if not uploaded_file:
            return Response(
                {'error': 'Please upload a file.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if report_type not in ['XRAY', 'BLOOD_REPORT']:
            return Response(
                {'error': 'report_type must be XRAY or BLOOD_REPORT.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Save file
        file_path = default_storage.save(
            f'reports/{request.user.id}/{uploaded_file.name}',
            uploaded_file,
        )
        full_path = os.path.join(settings.MEDIA_ROOT, file_path)

        # Analyze
        try:
            if report_type == 'XRAY':
                result, summary = self._analyze_xray(full_path)
            else:
                result, summary = self._analyze_blood_report(full_path)
        except Exception as e:
            logger.error(f'Report analysis error: {e}')
            return Response(
                {'error': f'Analysis failed: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        # Persist
        analysis = MedicalReportAnalysis.objects.create(
            patient=request.user,
            report_file=file_path,
            analysis_type=report_type,
            result_json=result,
            summary=summary,
        )

        return Response({
            'analysis_id': analysis.id,
            'analysis_type': report_type,
            'result': result,
            'summary': summary,
        })

    def _analyze_xray(self, file_path):
        """
        X-Ray CNN analysis.
        Tries to load a trained TensorFlow/Keras model.
        Falls back to a deterministic placeholder.
        """
        result = {
            'filename': os.path.basename(file_path),
            'findings': [],
            'is_abnormal': False,
        }
        summary = ''

        # ── Try CNN model ──
        try:
            import numpy as np
            from PIL import Image
            model_path = os.path.join(
                settings.BASE_DIR, 'clinical_ai', 'ml_models', 'lung_cnn.h5'
            )
            if os.path.exists(model_path):
                import tensorflow as tf
                model = tf.keras.models.load_model(model_path)
                img = Image.open(file_path).convert('RGB').resize((224, 224))
                img_arr = np.array(img) / 255.0
                img_arr = np.expand_dims(img_arr, axis=0)
                pred = model.predict(img_arr, verbose=0)[0][0]
                is_pneumonia = pred > 0.5
                confidence = pred if is_pneumonia else 1 - pred
                result['is_abnormal'] = is_pneumonia
                result['confidence'] = round(float(confidence) * 100, 1)
                if is_pneumonia:
                    result['findings'].append('Signs of pneumonia detected.')
                    summary = (
                        f'Pneumonia detected with {result["confidence"]}% confidence. '
                        'Consult a pulmonologist for treatment.'
                    )
                else:
                    result['findings'].append('No pneumonia detected.')
                    summary = 'No signs of pneumonia. Lungs appear normal.'
                return result, summary
        except Exception as e:
            logger.warning(f'CNN model load failed: {e}')

        # ── Placeholder ──
        result['findings'].append('X-Ray analysis model not loaded — showing demo result.')
        result['findings'].append('Image received and processed successfully.')
        result['is_abnormal'] = False
        result['confidence'] = 88.5
        summary = (
            'X-Ray image received. To enable AI diagnosis, please train and deploy '
            'the CNN model (see clinical_ai/train_scripts/train_cnn.py). '
            'In production, this returns a real pneumonia/abnormality detection result.'
        )
        return result, summary

    def _analyze_blood_report(self, file_path):
        """
        OCR-based blood report analysis.
        Tries EasyOCR or PyTesseract; falls back gracefully.
        """
        extracted_text = ''
        result = {
            'filename': os.path.basename(file_path),
            'parameters': {},
            'abnormal_flags': [],
        }

        # ── Try OCR ──
        ocr_used = None
        try:
            # Try EasyOCR first
            import easyocr
            reader = easyocr.Reader(['en'], gpu=False)
            ocr_result = reader.readtext(file_path, detail=0)
            extracted_text = ' '.join(ocr_result)
            ocr_used = 'easyocr'
        except ImportError:
            try:
                # Fall back to pytesseract
                from PIL import Image
                import pytesseract
                img = Image.open(file_path)
                extracted_text = pytesseract.image_to_string(img)
                ocr_used = 'pytesseract'
            except ImportError:
                extracted_text = (
                    'OCR libraries not installed. Install easyocr or pytesseract '
                    'for blood report analysis.'
                )

        result['raw_text'] = extracted_text[:500]
        result['ocr_engine'] = ocr_used or 'none'

        # ── Parse known biomarkers ──
        # Reference ranges (biological)
        references = {
            'hemoglobin':    {'low': 12.0, 'high': 16.0, 'unit': 'g/dL'},
            'wbc':           {'low': 4000, 'high': 11000, 'unit': '/µL'},
            'platelets':     {'low': 150000, 'high': 450000, 'unit': '/µL'},
            'rbc':           {'low': 4.5, 'high': 5.5, 'unit': 'M/µL'},
            'glucose_fasting': {'low': 70, 'high': 100, 'unit': 'mg/dL'},
            'creatinine':    {'low': 0.6, 'high': 1.2, 'unit': 'mg/dL'},
        }

        biomarkers = ['hemoglobin', 'wbc', 'platelets', 'rbc', 'glucose', 'creatinine']
        for marker in biomarkers:
            ref_key = marker if marker in references else None
            if not ref_key:
                continue
            ref = references[ref_key]
            # Simple keyword + number extraction
            import re
            pattern = rf'{marker}[:\s]*([\d.]+)'
            match = re.search(pattern, extracted_text.lower())
            if match:
                value = float(match.group(1))
                status = 'normal'
                if value < ref['low']:
                    status = 'low'
                elif value > ref['high']:
                    status = 'high'
                result['parameters'][marker] = {
                    'value': value,
                    'unit': ref['unit'],
                    'reference_range': f'{ref["low"]}-{ref["high"]}',
                    'status': status,
                }
                if status != 'normal':
                    result['abnormal_flags'].append(
                        f'{marker.upper()}: {value} {ref["unit"]} '
                        f'({"below" if status == "low" else "above"} normal range)'
                    )

        # Summary
        if result['abnormal_flags']:
            summary = (
                'Abnormal values detected: ' + '; '.join(result['abnormal_flags']) +
                '. Please consult a physician for follow-up.'
            )
        else:
            summary = (
                'All detected biomarkers appear within normal ranges. '
                'Always confirm with a doctor.'
            )

        return result, summary
