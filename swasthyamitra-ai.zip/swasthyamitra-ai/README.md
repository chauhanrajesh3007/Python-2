# 🏥 SwasthyaMitra AI — Rural Healthcare Intelligence Platform

**SwasthyaMitra AI** bridges the gap between rural patients and specialist doctors using
machine learning, deep learning, and structured healthcare services — all in one platform.

---

## 🚀 Quick Start (Local Development)

### Prerequisites
- **Python 3.11+**
- **Node.js 18+** (for frontend)
- **pip** & **npm**

### 1. Backend Setup (Django)

```bash
cd backend/

# Create & activate virtual environment
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate   # Windows

# Install dependencies
pip install -r requirements.txt

# Run migrations
python manage.py migrate

# Create a superuser (optional — for Django Admin)
python manage.py createsuperuser

# Start the development server
python manage.py runserver 0.0.0.0:8000
```

**API Base URL:** `http://localhost:8000/api/`

### 2. Frontend Setup (React + Vite)

```bash
cd frontend/

# Install dependencies
npm install

# Start the dev server
npm run dev
```

**Frontend URL:** `http://localhost:5173`

---

## 📡 API Endpoints

### 🔐 Authentication (`/api/auth/`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/register/` | Register (PATIENT, DOCTOR, or AMBULANCE_DRIVER) |
| POST | `/login/` | Login — returns JWT access + refresh tokens |
| POST | `/token/refresh/` | Refresh expired access token |
| GET | `/profile/` | Get authenticated user's profile |
| PUT | `/profile/` | Update profile |
| POST | `/change-password/` | Change password |
| GET | `/doctors/` | List all verified doctors |

### 🧠 Clinical AI (`/api/ai/`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/symptom-checker/` | Submit symptoms → get top-3 disease predictions |
| POST | `/predict-diabetes/` | Diabetes risk assessment |
| POST | `/predict-heart/` | Heart disease risk assessment |
| POST | `/analyze-report/` | Upload X-Ray/Blood Report → AI analysis |

### 🏥 Services (`/api/services/`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET/POST | `/appointments/` | List/Create appointments |
| GET/PATCH | `/appointments/<id>/` | View/Update appointment |
| POST | `/appointments/<id>/confirm-payment/` | Confirm razorpay payment |
| GET/POST | `/reminders/` | List/Create medicine reminders |
| GET/PATCH/DELETE | `/reminders/<id>/` | Manage reminder |
| POST | `/nearest-ambulance/` | Find nearest ambulance |
| GET/POST | `/ambulance-requests/` | List/Create emergency requests |
| POST | `/update-location/` | Driver updates GPS location |
| GET/POST | `/subscription/` | View/Upgrade subscription plan |

---

## 📁 Project Structure

```
swasthyamitra-ai/
├── backend/
│   ├── manage.py
│   ├── core/               # Django settings, root URLs
│   ├── accounts/           # User models, auth views, profiles
│   ├── clinical_ai/        # ML models, symptom checker, risk predictors, report analyzer
│   │   ├── ml_models/      # Trained .pkl and .h5 files
│   │   └── train_scripts/  # Model training scripts
│   ├── services/           # Appointments, reminders, ambulance, subscriptions
│   └── requirements.txt
│
└── frontend/               # React + Vite + Tailwind CSS
    └── src/
        ├── components/     # Reusable UI components
        ├── context/        # Auth context (JWT)
        └── pages/          # Dashboard pages
```

---

## 🧪 ML Models

| Model | Dataset | Algorithm |
|-------|---------|-----------|
| Symptom Checker | Kaggle: Disease Symptom Prediction | Random Forest (100 estimators) |
| Diabetes Risk | Pima Indians Diabetes | Logistic Regression |
| Heart Disease | Cleveland Heart Disease | Random Forest |
| Chest X-Ray | Chest X-Ray Pneumonia | MobileNetV2 (CNN) |
| Blood Report OCR | N/A | EasyOCR / PyTesseract |

> **Training Scripts** are in `backend/clinical_ai/train_scripts/` — run them to generate `.pkl`/`.h5` files.
> Until models are trained, the API uses heuristic fallbacks (perfect for demo/viva).

---

## 💰 Monetization

- **Free Tier:** 3 AI checks per day
- **Premium (₹499/month):** Unlimited AI checks, priority booking
- **Consultation Fee:** ₹199 per appointment (via Razorpay test mode)

---

## 🔑 Environment Variables (Optional)

| Variable | Default | Purpose |
|----------|---------|---------|
| `TWILIO_ACCOUNT_SID` | — | WhatsApp reminders |
| `TWILIO_AUTH_TOKEN` | — | WhatsApp reminders |
| `RAZORPAY_KEY_ID` | `rzp_test_placeholder` | Payment gateway |
| `RAZORPAY_KEY_SECRET` | `placeholder` | Payment gateway |

---

## 👨‍💻 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite, Tailwind CSS, Axios |
| Backend | Django 5, Django REST Framework |
| Auth | SimpleJWT (JSON Web Tokens) |
| Database | SQLite3 (dev) / PostgreSQL (production) |
| ML/DL | Scikit-Learn, TensorFlow/Keras |
| Payments | Razorpay |
| Notifications | Twilio WhatsApp API |
| Video Calls | Jitsi Meet (open-source) |

---

## 📝 Academic Context

This project is designed for a **Semester 4 Computer Science/IT student** to demonstrate:
- Full-stack web development (React + Django)
- Machine Learning integration in a real-world application
- RESTful API design with JWT authentication
- Role-based access control (Patient, Doctor, Ambulance Driver)
- Payment gateway integration
- Background task scheduling (medicine reminders)
- GPS-based nearest-ambulance algorithm (Haversine formula)

---

## 📄 License

This project is created for academic evaluation purposes.

---

*Built with ❤️ for rural healthcare accessibility in India.*
