import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import PatientDashboard from './pages/PatientDashboard';
import DoctorDashboard from './pages/DoctorDashboard';
import SymptomCheckerPage from './pages/SymptomCheckerPage';
import RiskCalculatorPage from './pages/RiskCalculatorPage';
import ReportAnalyzerPage from './pages/ReportAnalyzerPage';
import EmergencyPage from './pages/EmergencyPage';
import AppointmentsPage from './pages/AppointmentsPage';

function ProtectedRoute({ children, allowedRoles }) {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }
  if (!user) return <Navigate to="/login" />;
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/" />;
  }
  return children;
}

function RootRedirect() {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" />;
  if (user.role === 'DOCTOR') return <Navigate to="/doctor-dashboard" />;
  return <Navigate to="/patient-dashboard" />;
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public */}
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />

          {/* Patient Routes */}
          <Route path="/patient-dashboard" element={
            <ProtectedRoute allowedRoles={['PATIENT']}>
              <PatientDashboard />
            </ProtectedRoute>
          } />
          <Route path="/symptom-checker" element={
            <ProtectedRoute allowedRoles={['PATIENT']}>
              <SymptomCheckerPage />
            </ProtectedRoute>
          } />
          <Route path="/risk-calculator" element={
            <ProtectedRoute allowedRoles={['PATIENT']}>
              <RiskCalculatorPage />
            </ProtectedRoute>
          } />
          <Route path="/report-analyzer" element={
            <ProtectedRoute allowedRoles={['PATIENT']}>
              <ReportAnalyzerPage />
            </ProtectedRoute>
          } />
          <Route path="/emergency" element={
            <ProtectedRoute>
              <EmergencyPage />
            </ProtectedRoute>
          } />
          <Route path="/appointments" element={
            <ProtectedRoute allowedRoles={['PATIENT']}>
              <AppointmentsPage />
            </ProtectedRoute>
          } />

          {/* Doctor Routes */}
          <Route path="/doctor-dashboard" element={
            <ProtectedRoute allowedRoles={['DOCTOR']}>
              <DoctorDashboard />
            </ProtectedRoute>
          } />

          {/* Root redirect */}
          <Route path="/" element={<RootRedirect />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
