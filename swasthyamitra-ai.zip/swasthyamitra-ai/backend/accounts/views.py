"""
Accounts — Auth & Profile Views
"""
from rest_framework import status, generics, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.decorators import api_view, permission_classes
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import get_user_model
from .models import PatientProfile, DoctorProfile, AmbulanceDriverProfile
from .serializers import (
    UserRegisterSerializer, LoginSerializer,
    UserSerializer, PatientProfileSerializer,
    DoctorProfileSerializer, AmbulanceDriverProfileSerializer,
    ChangePasswordSerializer,
)

User = get_user_model()


def _get_tokens_for_user(user):
    """Helper: create JWT token pair for a user."""
    refresh = RefreshToken.for_user(user)
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }


def _get_profile_data(user):
    """Return the role-specific profile for the logged-in user."""
    base = UserSerializer(user).data
    if user.role == User.Role.PATIENT:
        try:
            base['profile'] = PatientProfileSerializer(user.patient_profile).data
        except PatientProfile.DoesNotExist:
            base['profile'] = None
    elif user.role == User.Role.DOCTOR:
        try:
            base['profile'] = DoctorProfileSerializer(user.doctor_profile).data
        except DoctorProfile.DoesNotExist:
            base['profile'] = None
    elif user.role == User.Role.AMBULANCE_DRIVER:
        try:
            base['profile'] = AmbulanceDriverProfileSerializer(user.ambulance_driver_profile).data
        except AmbulanceDriverProfile.DoesNotExist:
            base['profile'] = None
    else:
        base['profile'] = None
    return base


# ═══════════════════════════════════════════════════════════════════════════
# Registration
# ═══════════════════════════════════════════════════════════════════════════

class RegisterView(generics.CreateAPIView):
    """
    POST /api/auth/register/
    Creates a new user with role-specific profile.
    Returns JWT tokens on success.
    """
    serializer_class = UserRegisterSerializer
    permission_classes = [permissions.AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        tokens = _get_tokens_for_user(user)
        return Response({
            'message': 'Registration successful.',
            'tokens': tokens,
            'user': _get_profile_data(user),
        }, status=status.HTTP_201_CREATED)


# ═══════════════════════════════════════════════════════════════════════════
# Login
# ═══════════════════════════════════════════════════════════════════════════

class LoginView(APIView):
    """
    POST /api/auth/login/
    Authenticates a user and returns JWT tokens.
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        tokens = _get_tokens_for_user(user)
        return Response({
            'message': 'Login successful.',
            'tokens': tokens,
            'user': _get_profile_data(user),
        }, status=status.HTTP_200_OK)


# ═══════════════════════════════════════════════════════════════════════════
# Profile
# ═══════════════════════════════════════════════════════════════════════════

class ProfileView(APIView):
    """
    GET  /api/auth/profile/   — Retrieve own profile
    PUT  /api/auth/profile/   — Update own profile
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        return Response({'user': _get_profile_data(request.user)})

    def put(self, request):
        user = request.user
        # Update base User fields
        user_serializer = UserSerializer(user, data=request.data, partial=True)
        user_serializer.is_valid(raise_exception=True)
        user_serializer.save()

        # Update role-specific profile
        profile_data = request.data.get('profile', {})
        if profile_data:
            try:
                if user.role == User.Role.PATIENT:
                    prof = user.patient_profile
                    ps = PatientProfileSerializer(prof, data=profile_data, partial=True)
                    ps.is_valid(raise_exception=True)
                    ps.save()
                elif user.role == User.Role.DOCTOR:
                    prof = user.doctor_profile
                    ps = DoctorProfileSerializer(prof, data=profile_data, partial=True)
                    ps.is_valid(raise_exception=True)
                    ps.save()
                elif user.role == User.Role.AMBULANCE_DRIVER:
                    prof = user.ambulance_driver_profile
                    ps = AmbulanceDriverProfileSerializer(prof, data=profile_data, partial=True)
                    ps.is_valid(raise_exception=True)
                    ps.save()
            except (PatientProfile.DoesNotExist, DoctorProfile.DoesNotExist,
                    AmbulanceDriverProfile.DoesNotExist):
                return Response(
                    {'error': 'Profile not found for this user role.'},
                    status=status.HTTP_404_NOT_FOUND,
                )

        return Response({
            'message': 'Profile updated successfully.',
            'user': _get_profile_data(user),
        })


# ═══════════════════════════════════════════════════════════════════════════
# Change Password
# ═══════════════════════════════════════════════════════════════════════════

class ChangePasswordView(APIView):
    """
    POST /api/auth/change-password/
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = ChangePasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = request.user
        if not user.check_password(serializer.validated_data['old_password']):
            return Response(
                {'old_password': 'Current password is incorrect.'},
                status=status.HTTP_400_BAD_REQUEST,
            )
        user.set_password(serializer.validated_data['new_password'])
        user.save()
        return Response({'message': 'Password changed successfully.'})


# ═══════════════════════════════════════════════════════════════════════════
# Public Doctor Listing (for patients to browse)
# ═══════════════════════════════════════════════════════════════════════════

class DoctorListView(generics.ListAPIView):
    """
    GET /api/auth/doctors/
    Returns all verified doctors with their profiles (public).
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = DoctorProfileSerializer
    queryset = DoctorProfile.objects.filter(user__is_verified=True).select_related('user')

    def get_queryset(self):
        qs = super().get_queryset()
        specialization = self.request.query_params.get('specialization')
        city = self.request.query_params.get('city')
        if specialization:
            qs = qs.filter(specialization__icontains=specialization)
        if city:
            qs = qs.filter(city__icontains=city)
        return qs
