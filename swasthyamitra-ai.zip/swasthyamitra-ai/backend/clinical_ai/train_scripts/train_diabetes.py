"""
train_diabetes.py — Train Logistic Regression on the Pima Indians Diabetes Dataset.

Dataset: Pima Indians Diabetes Database (Kaggle)
Target:   Outcome (0 = no diabetes, 1 = diabetes)

Usage:
    python train_diabetes.py

Outputs:
    clinical_ai/ml_models/diabetes_model.pkl
"""
import os
import sys
import pickle
import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, roc_auc_score

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

MODEL_DIR = os.path.join(os.path.dirname(__file__), '..', 'ml_models')
os.makedirs(MODEL_DIR, exist_ok=True)

DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'datasets', 'diabetes.csv')

try:
    df = pd.read_csv(DATA_PATH)
    print(f'Loaded dataset: {df.shape[0]} rows × {df.shape[1]} columns')
except FileNotFoundError:
    print(f'Dataset not found at {DATA_PATH}')
    print('Please download the Pima Indians Diabetes dataset from Kaggle.')
    print('Place it at: clinical_ai/datasets/diabetes.csv')
    sys.exit(1)

# Features: Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI,
#           DiabetesPedigreeFunction, Age
# Target: Outcome
feature_cols = [
    'Pregnancies', 'Glucose', 'BloodPressure', 'SkinThickness',
    'Insulin', 'BMI', 'DiabetesPedigreeFunction', 'Age',
]

X = df[feature_cols]
y = df['Outcome']

# Handle zeros in columns where zero is physiologically invalid
for col in ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']:
    X[col] = X[col].replace(0, X[col].median())

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

model = LogisticRegression(max_iter=1000, random_state=42)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]
acc = accuracy_score(y_test, y_pred)
auc = roc_auc_score(y_test, y_prob)

print(f'\nTest Accuracy: {acc:.4f}')
print(f'ROC AUC:       {auc:.4f}')
print('\nClassification Report:')
print(classification_report(y_test, y_pred, target_names=['No Diabetes', 'Diabetes']))

# Save
with open(os.path.join(MODEL_DIR, 'diabetes_model.pkl'), 'wb') as f:
    pickle.dump(model, f)

print(f'\n✅ Model saved to: {os.path.join(MODEL_DIR, "diabetes_model.pkl")}')
