"""
train_cnn.py — Train a lightweight CNN on the Chest X-Ray Pneumonia dataset.

Architecture: MobileNetV2-based transfer learning (or custom sequential CNN)
Dataset:      Kaggle Chest X-Ray Images (Pneumonia) — Normal vs Pneumonia

Usage:
    python train_cnn.py

Outputs:
    clinical_ai/ml_models/lung_cnn.h5
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

MODEL_DIR = os.path.join(os.path.dirname(__file__), '..', 'ml_models')
os.makedirs(MODEL_DIR, exist_ok=True)

DATASET_DIR = os.path.join(os.path.dirname(__file__), '..', 'datasets', 'chest_xray')

# Check for dataset
if not os.path.isdir(DATASET_DIR):
    print(f'Dataset directory not found: {DATASET_DIR}')
    print('Please download the Chest X-Ray Pneumonia dataset from Kaggle.')
    print('Expected structure: chest_xray/train/NORMAL/, chest_xray/train/PNEUMONIA/,')
    print('                    chest_xray/test/NORMAL/,  chest_xray/test/PNEUMONIA/')
    print('\nSkipping CNN training — download the dataset to enable this script.')
    sys.exit(0)

# ---------------------------------------------------------------------------
# Import TensorFlow only when dataset is present
# ---------------------------------------------------------------------------
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.preprocessing.image import ImageDataGenerator

print('TensorFlow version:', tf.__version__)

IMG_SIZE = 224
BATCH_SIZE = 32
EPOCHS = 10

# Data generators with augmentation
train_datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=15,
    zoom_range=0.1,
    horizontal_flip=True,
)

test_datagen = ImageDataGenerator(rescale=1./255)

train_generator = train_datagen.flow_from_directory(
    os.path.join(DATASET_DIR, 'train'),
    target_size=(IMG_SIZE, IMG_SIZE),
    batch_size=BATCH_SIZE,
    class_mode='binary',
)

test_generator = test_datagen.flow_from_directory(
    os.path.join(DATASET_DIR, 'test'),
    target_size=(IMG_SIZE, IMG_SIZE),
    batch_size=BATCH_SIZE,
    class_mode='binary',
    shuffle=False,
)

# ---------------------------------------------------------------------------
# Build Model: MobileNetV2 transfer learning
# ---------------------------------------------------------------------------
base_model = keras.applications.MobileNetV2(
    input_shape=(IMG_SIZE, IMG_SIZE, 3),
    include_top=False,
    weights='imagenet',
)
base_model.trainable = False  # Freeze base

model = keras.Sequential([
    base_model,
    layers.GlobalAveragePooling2D(),
    layers.Dropout(0.3),
    layers.Dense(128, activation='relu'),
    layers.Dropout(0.3),
    layers.Dense(1, activation='sigmoid'),
])

model.compile(
    optimizer=keras.optimizers.Adam(learning_rate=1e-3),
    loss='binary_crossentropy',
    metrics=['accuracy'],
)

model.summary()

# Train
history = model.fit(
    train_generator,
    epochs=EPOCHS,
    validation_data=test_generator,
)

# Evaluate
loss, acc = model.evaluate(test_generator)
print(f'\nTest Accuracy: {acc:.4f}')

# Save
output_path = os.path.join(MODEL_DIR, 'lung_cnn.h5')
model.save(output_path)
print(f'\n✅ CNN model saved to: {output_path}')
