"""
Accounts — Django Admin Registration
"""
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import (
    User, PatientProfile, DoctorProfile, AmbulanceDriverProfile,
    DoctorAvailabilitySlot,
)


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ['email', 'role', 'first_name', 'last_name', 'is_verified', 'is_active']
    list_filter = ['role', 'is_verified', 'is_active']
    search_fields = ['email', 'first_name', 'last_name']
    ordering = ['-created_at']
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Personal Info', {'fields': ('first_name', 'last_name', 'phone')}),
        ('Role & Status', {'fields': ('role', 'is_verified', 'is_active')}),
        ('Permissions', {'fields': ('is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Timestamps', {'fields': ('created_at', 'updated_at')}),
    )
    readonly_fields = ['created_at', 'updated_at']
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'password1', 'password2', 'role', 'first_name', 'last_name'),
        }),
    )


@admin.register(PatientProfile)
class PatientProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'age', 'gender', 'blood_group', 'city']
    search_fields = ['user__email', 'user__first_name', 'user__last_name', 'city']


@admin.register(DoctorProfile)
class DoctorProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'specialization', 'registration_number', 'consultation_fee', 'rating']
    search_fields = ['user__email', 'specialization', 'registration_number']


@admin.register(DoctorAvailabilitySlot)
class DoctorAvailabilitySlotAdmin(admin.ModelAdmin):
    list_display = ['doctor', 'day_of_week', 'start_time', 'end_time', 'max_patients_per_slot']


@admin.register(AmbulanceDriverProfile)
class AmbulanceDriverProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'vehicle_number', 'is_available', 'city']
    search_fields = ['user__email', 'vehicle_number', 'city']
