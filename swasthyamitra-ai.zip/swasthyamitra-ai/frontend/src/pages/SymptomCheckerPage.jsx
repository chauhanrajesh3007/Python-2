import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Loader2, Stethoscope, AlertCircle, CheckCircle2 } from 'lucide-react';
import api from '../services/api';

const COMMON_SYMPTOMS = [
  'Fever', 'Headache', 'Cough', 'Fatigue', 'Nausea',
  'Chest Pain', 'Breathlessness', 'Joint Pain', 'Stomach Pain',
  'Diarrhoea', 'Vomiting', 'Dizziness', 'Back Pain',
  'Loss of Appetite', 'Weight Loss', 'Sweating', 'Chills',
  'Muscle Pain', 'Anxiety', 'Weight Gain', 'Constipation',
  'Acidity', 'Indigestion', 'Blurred Vision', 'Runny Nose',
];

export default function SymptomCheckerPage() {
  const [selected, setSelected] = useState([]);
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const toggle = (s) => {
    setSelected((prev) =>
      prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]
    );
  };

  const handleSubmit = async () => {
    if (selected.length === 0) {
      setError('Please select at least one symptom.');
      return;
    }
    setError('');
    setLoading(true);
    setResults(null);
    try {
      const res = await api.post('/ai/symptom-checker/', { symptoms: selected });
      setResults(res.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Analysis failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 py-4">
        <div className="max-w-4xl mx-auto flex items-center gap-4">
          <Link to="/patient-dashboard" className="text-gray-500 hover:text-gray-700">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-lg font-semibold">AI Symptom Checker</h1>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-6">
        {error && (
          <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center gap-2">
            <AlertCircle className="w-4 h-4" /> {error}
          </div>
        )}

        {/* Symptom Selector */}
        <div className="card mb-6">
          <h2 className="text-lg font-semibold mb-4">Select Your Symptoms</h2>
          <p className="text-sm text-gray-500 mb-4">
            Selected: <span className="font-medium text-blue-600">{selected.length}</span> symptom(s)
          </p>
          <div className="flex flex-wrap gap-2">
            {COMMON_SYMPTOMS.map((s) => (
              <button
                key={s}
                onClick={() => toggle(s)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 border
                  ${selected.includes(s)
                    ? 'bg-blue-600 text-white border-blue-600 shadow-md'
                    : 'bg-white text-gray-700 border-gray-300 hover:border-blue-400'
                  }`}
              >
                {s}
              </button>
            ))}
          </div>
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="btn-primary mt-6 flex items-center gap-2"
          >
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            {loading ? 'Analyzing...' : 'Analyze Symptoms'}
          </button>
        </div>

        {/* Results */}
        {results && (
          <div className="card">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Stethoscope className="w-5 h-5 text-blue-600" />
              Diagnostic Predictions
            </h2>

            {results.symptoms_unknown?.length > 0 && (
              <p className="text-sm text-amber-600 mb-4">
                Some symptoms were not recognized: {results.symptoms_unknown.join(', ')}.
                The analysis is based on {results.symptoms_recognized?.length || 0} recognized symptoms.
              </p>
            )}

            <div className="space-y-3">
              {results.predictions?.map((p, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200">
                  <div className="flex items-center gap-3">
                    <span className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-sm font-bold">
                      {i + 1}
                    </span>
                    <div>
                      <p className="font-semibold text-gray-900">{p.disease}</p>
                      <p className="text-sm text-gray-500">Possible condition</p>
                    </div>
                  </div>
                  <span className="text-lg font-bold text-blue-600">{p.confidence}%</span>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-sm text-amber-800 flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                {results.recommendation}
              </p>
            </div>

            <Link to="/appointments" className="btn-primary mt-4 inline-flex">
              Book a Doctor
            </Link>
          </div>
        )}
      </main>
    </div>
  );
}
