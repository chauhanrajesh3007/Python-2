import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import {
  Heart, Stethoscope, AlertTriangle, FileSearch,
  Calendar, Bell, Siren, LogOut, Activity, CreditCard,
} from 'lucide-react';

export default function PatientDashboard() {
  const { user, logout } = useAuth();
  const [subscription, setSubscription] = useState(null);
  const [recentChecks, setRecentChecks] = useState([]);

  useEffect(() => {
    api.get('/services/subscription/').then(r => setSubscription(r.data)).catch(() => {});
    api.get('/ai/symptom-checker/').catch(() => {}); // warm-up
  }, []);

  const features = [
    { to: '/symptom-checker', icon: Stethoscope, label: 'Symptom Checker', desc: 'AI-powered diagnosis', color: 'bg-blue-100 text-blue-600' },
    { to: '/risk-calculator', icon: Activity, label: 'Risk Calculator', desc: 'Diabetes & Heart risk', color: 'bg-purple-100 text-purple-600' },
    { to: '/report-analyzer', icon: FileSearch, label: 'Report Analyzer', desc: 'X-Ray & Blood reports', color: 'bg-green-100 text-green-600' },
    { to: '/appointments', icon: Calendar, label: 'Appointments', desc: 'Book doctor consultations', color: 'bg-orange-100 text-orange-600' },
    { to: '/emergency', icon: Siren, label: 'SOS Emergency', desc: 'Find nearest ambulance', color: 'bg-red-100 text-red-600' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Heart className="w-8 h-8 text-blue-600" />
            <div>
              <h1 className="text-xl font-bold text-gray-900">SwasthyaMitra AI</h1>
              <p className="text-xs text-gray-500">Welcome, {user?.first_name || 'Patient'}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {subscription?.tier === 'PREMIUM' && (
              <span className="bg-yellow-100 text-yellow-800 text-xs font-medium px-2.5 py-1 rounded-full flex items-center gap-1">
                <CreditCard className="w-3 h-3" /> Premium
              </span>
            )}
            <button onClick={logout} className="text-gray-500 hover:text-red-600 transition-colors">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Daily AI Usage */}
        {user?.profile && (
          <div className="mb-6 p-4 bg-white rounded-xl border border-gray-200 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-700">Daily AI Checks</p>
              <p className="text-2xl font-bold text-blue-600">
                {user.profile.daily_ai_check_count || 0} / {subscription?.tier === 'PREMIUM' ? '∞' : '3'}
              </p>
            </div>
            {subscription?.tier !== 'PREMIUM' && (
              <Link to="/subscription" className="btn-primary text-sm">
                Upgrade — ₹499/mo
              </Link>
            )}
          </div>
        )}

        {/* Feature Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map(({ to, icon: Icon, label, desc, color }) => (
            <Link key={to} to={to} className="card group cursor-pointer hover:border-blue-300">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${color}`}>
                <Icon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                {label}
              </h3>
              <p className="text-sm text-gray-500 mt-1">{desc}</p>
            </Link>
          ))}
        </div>

        {/* SOS Emergency Quick Access */}
        <div className="mt-8">
          <Link
            to="/emergency"
            className="block w-full bg-red-600 hover:bg-red-700 text-white text-center py-5 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-200"
          >
            <Siren className="w-8 h-8 mx-auto mb-2 animate-pulse" />
            <span className="text-xl font-bold">EMERGENCY SOS</span>
            <p className="text-red-100 text-sm mt-1">Tap for immediate ambulance dispatch</p>
          </Link>
        </div>
      </main>
    </div>
  );
}
