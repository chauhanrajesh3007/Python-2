"""
Clinical AI — Django Admin Registration
"""
from django.contrib import admin
from .models import SymptomCheckResult, RiskPredictionResult, MedicalReportAnalysis


@admin.register(SymptomCheckResult)
class SymptomCheckResultAdmin(admin.ModelAdmin):
    list_display = ['patient', 'created_at']
    search_fields = ['patient__email']


@admin.register(RiskPredictionResult)
class RiskPredictionResultAdmin(admin.ModelAdmin):
    list_display = ['patient', 'prediction_type', 'risk_score', 'is_high_risk', 'created_at']
    list_filter = ['prediction_type', 'is_high_risk']


@admin.register(MedicalReportAnalysis)
class MedicalReportAnalysisAdmin(admin.ModelAdmin):
    list_display = ['patient', 'analysis_type', 'created_at']
    list_filter = ['analysis_type']
